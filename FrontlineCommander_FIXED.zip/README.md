# Frontline Commander

Android game prototype built with Kotlin + Jetpack Compose.

## Build

The GitHub Actions workflow installs Java 17 and Gradle 8.13, then builds `assembleDebug`.

## AdMob

The project contains a banner integration dependency. The manifest currently uses Google's test App ID. Replace it with the AdMob **App ID** (`ca-app-pub-...~...`) before release, and use the production banner ad unit only for release builds. During development, use Google's test banner ID.
