# Frontline Commander — Cloud Build Package

Questo pacchetto contiene il progetto Android pronto per una build cloud.

## Build
Eseguire dalla root del progetto:

    gradle :app:assembleDebug

Output:

    app/build/outputs/apk/debug/app-debug.apk

## Requisiti
- JDK 17
- Android SDK con platform 36 e build-tools compatibili
- Gradle 8.13 (il wrapper punta alla distribuzione ufficiale)

## Installazione sul telefono
L'APK debug risultante può essere trasferito sul dispositivo Android e installato per il test.

## Nota
Il progetto non contiene chiavi di firma release. Per una pubblicazione sul Play Store sarà necessario creare una keystore e configurare una build release firmata.
