package com.frontline.commander

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Navy=Color(0xFF24324A); private val Cream=Color(0xFFFFFAF0)
private val Blue=Color(0xFF4D8DF7); private val Yellow=Color(0xFFFFD24A)
private val Green=Color(0xFF68C47B); private val Orange=Color(0xFFFF9852)

class MainActivity: ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{FrontlineApp()}}
}

@Composable fun FrontlineApp(){
 var coins by remember{mutableIntStateOf(1250)}
 var power by remember{mutableIntStateOf(18)}
 var maxPower by remember{mutableIntStateOf(50)}
 var xp by remember{mutableIntStateOf(240)}
 var hq by remember{mutableIntStateOf(2)}
 var message by remember{mutableStateOf("Pronto al lancio, Comandante!")}
 var reels by remember{mutableStateOf(listOf("🪖","🪙","🛡️"))}
 var spinning by remember{mutableStateOf(false)}
 var streak by remember{mutableIntStateOf(1)}

 LaunchedEffect(Unit){ while(true){ delay(300_000); if(power<maxPower) power++ } }

 MaterialTheme(colorScheme=lightColorScheme(primary=Blue,background=Cream)){
  Scaffold(bottomBar={NavigationBar(containerColor=Color.White){
   NavigationBarItem(true,{}, {Text("🏠")}, label={Text("Base")}); NavigationBarItem(false,{}, {Text("🎰")}, label={Text("Ruota")}); NavigationBarItem(false,{}, {Text("💥")}, label={Text("Raid")}); NavigationBarItem(false,{}, {Text("🪖")}, label={Text("Squadra")})
  }}){ pad->
   Column(Modifier.padding(pad).fillMaxSize().background(Cream).padding(14.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
     Row(verticalAlignment=Alignment.CenterVertically){Text("★",fontSize=28.sp); Spacer(Modifier.width(7.dp)); Column{Text("FRONTLINE",fontWeight=FontWeight.ExtraBold,fontSize=18.sp);Text("COMMANDER",fontSize=9.sp,color=Color.Gray)}} 
     Row{Resource("🪙",coins.toString());Spacer(Modifier.width(5.dp));Resource("⚡",power.toString())}
    }
    Spacer(Modifier.height(14.dp))
    Card(shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFE8F7FF))){
     Row(Modifier.fillMaxWidth().padding(22.dp),verticalAlignment=Alignment.CenterVertically){
      Column(Modifier.weight(1f)){Text("SETTORE 07",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Gray);Text("La tua base.",fontSize=30.sp,fontWeight=FontWeight.ExtraBold);Text("Gira, accumula e conquista.",color=Color(0xFF65758C));Spacer(Modifier.height(12.dp))
       Text("⚡ POTERE OPERATIVO  $power/$maxPower",fontWeight=FontWeight.Bold,fontSize=11.sp);LinearProgressIndicator({power.toFloat()/maxPower},Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(8.dp)),color=Yellow,trackColor=Color.White)
      }; Text("🏢\n📡\n🛡️",fontSize=42.sp,lineHeight=52.sp)
     }
    }
    Spacer(Modifier.height(18.dp))
    Text("CENTRO OPERAZIONI",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Gray);Text("Ruota tattica",fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
    Spacer(Modifier.height(8.dp))
    Card(shape=RoundedCornerShape(25.dp),colors=CardDefaults.cardColors(containerColor=Navy)){
     Column(Modifier.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){
      Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("RUOTA TATTICA",color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp);Text("STREAK ×$streak",color=Yellow,fontWeight=FontWeight.Bold,fontSize=12.sp)}
      Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){reels.forEach{Text(it,Modifier.weight(1f).clip(RoundedCornerShape(17.dp)).background(Color.White).padding(vertical=23.dp),fontSize=42.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)}}
      Text(message,color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(8.dp))
      Button(onClick={ if(!spinning && power>0){spinning=true;power--;reels=listOf("💥","⚙️","🎯"); message="..."; 
       // short deterministic animation via state effect below
      }},enabled=!spinning && power>0,colors=ButtonDefaults.buttonColors(containerColor=Yellow,contentColor=Navy),modifier=Modifier.fillMaxWidth()){Text("⚡ GIRA • 1 POTERE",fontWeight=FontWeight.ExtraBold,fontSize=16.sp)}
     }
    }
    LaunchedEffect(spinning){if(spinning){delay(650);val r=listOf("🪖","🪙","🛡️","💥","⚙️","🎯","⭐");reels=List(3){r.random()};val same=reels.distinct().size==1;val pair=reels.distinct().size==2;when{same->{val gain=600+streak*100;coins+=gain;xp+=80;power=(power+3).coerceAtMost(maxPower);streak++;message="JACKPOT! +$gain 🪙 • +3 ⚡"};pair->{coins+=180;xp+=30;streak++;message="COMBINAZIONE! +180 🪙"};else->{coins+=60;xp+=10;streak=1;message="Rifornimento! +60 🪙"}};spinning=false}}
    Spacer(Modifier.height(18.dp))
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.Bottom){Column{Text("IL TUO AVAMPPOSTO",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Gray);Text("Costruisci e potenzia",fontSize=25.sp,fontWeight=FontWeight.ExtraBold)}Button(onClick={val cost=500+350*hq;if(coins>=cost){coins-=cost;hq++;maxPower+=5;xp+=40;message="Base potenziata! ★"}},colors=ButtonDefaults.buttonColors(containerColor=Navy)){Text("⬆ POTENZIA")}}
    Spacer(Modifier.height(9.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){Building("🏠","Comando","Lv.$hq",Modifier.weight(1f));Building("🛠️","Officina","+ produzione",Modifier.weight(1f));Building("📡","Radar","+ raid",Modifier.weight(1f))}
    Spacer(Modifier.height(18.dp))
    Text("ATTACCO & RAID",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Gray);Text("Operazioni lampo",fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
    Spacer(Modifier.height(8.dp))
    listOf("🌲 🪖 🌲" to "Sentiero Verde","☀️ 🏜️ 🛡️" to "Deposito Rosso","🌊 🛩️ 🌊" to "Onda Blu").forEachIndexed{i,p->Card(Modifier.fillMaxWidth().padding(bottom=8.dp).clickable{val cost=i+3;if(power>=cost){power-=cost;coins+=listOf(240,380,300)[i];xp+=40;message="Operazione riuscita!";}else message="Potere insufficiente ⚡"},shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(p.first,fontSize=28.sp);Spacer(Modifier.width(12.dp));Column{Text(p.second,fontWeight=FontWeight.ExtraBold,fontSize=18.sp);Text("⚡ ${i+3} • ricompensa",color=Color.Gray,fontSize=11.sp)}}})
    Spacer(Modifier.height(20.dp));Text("PROGRESSIONE",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Gray);Text("Squadra Alpha",fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){Unit("🪖","Ranger","Lv.3",Modifier.weight(1f));Unit("🧨","Blaster","Lv.2",Modifier.weight(1f));Unit("🛡️","Guard","Lv.3",Modifier.weight(1f))}
    Spacer(Modifier.height(30.dp))
   }
  }
 }
}

@Composable fun Resource(icon:String,value:String){Text("$icon $value",modifier=Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White).padding(8.dp),fontWeight=FontWeight.Bold,fontSize=12.sp)}
@Composable fun Building(icon:String,name:String,sub:String,mod:Modifier){Card(mod,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text(icon,fontSize=30.sp);Text(name,fontWeight=FontWeight.Bold);Text(sub,fontSize=10.sp,color=Color.Gray)}}}
@Composable fun Unit(icon:String,name:String,lv:String,mod:Modifier){Card(mod,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=30.sp);Text(name,fontWeight=FontWeight.Bold,fontSize=12.sp);Text(lv,fontSize=10.sp,color=Color.Gray)}}}
