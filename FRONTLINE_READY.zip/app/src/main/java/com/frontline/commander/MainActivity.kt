package com.frontline.commander

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.random.Random

private val Sky = Color(0xFF7FB9CF)
private val Grass = Color(0xFF557A3B)
private val Olive = Color(0xFF405522)
private val OliveDark = Color(0xFF1E2F13)
private val OlivePanel = Color(0xFF344620)
private val Metal = Color(0xFF76785D)
private val MetalLight = Color(0xFFB3B18A)
private val MetalDark = Color(0xFF292C21)
private val Gold = Color(0xFFFFC52D)
private val GoldDark = Color(0xFF8C6418)
private val Red = Color(0xFFE64630)
private val RedDark = Color(0xFF8E241B)
private val Blue = Color(0xFF1E83B7)
private val Purple = Color(0xFF7040A1)
private val Cream = Color(0xFFFFF7DE)
private val White = Color(0xFFFFFFFF)

private const val MAX_SPINS = 100
private const val STARTING_SPINS = 17
private const val SPIN_RECHARGE_MS = 3 * 60 * 1000L

private data class Symbol(val icon: String, val name: String)
private data class WinRule(val symbol: String, val label: String, val multiplier: Int)

private val slotSymbols = listOf(
    Symbol("🪖", "ELMETTO"),
    Symbol("🎖️", "MEDAGLIA"),
    Symbol("🚁", "ELICOTTERO"),
    Symbol("🛡️", "SCUDO"),
    Symbol("📦", "CASSA"),
    Symbol("✈️", "AEREO"),
    Symbol("💣", "GRANATA"),
    Symbol("⭐", "STELLA")
)

private val winRules = listOf(
    WinRule("🪖", "ELMETTI", 2),
    WinRule("🎖️", "MEDAGLIE", 3),
    WinRule("📦", "CASSE", 4),
    WinRule("💣", "GRANATE", 6),
    WinRule("🚁", "ELICOTTERI", 10),
    WinRule("🛡️", "SCUDI", 15),
    WinRule("✈️", "AEREI", 20),
    WinRule("⭐", "STELLE", 50)
)

enum class GameTab { SHOP, CARDS, SLOT, BASE, ALLIANCE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrontlineApp() }
    }
}

private class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("frontline_game", Context.MODE_PRIVATE)
    var coins: Int get() = prefs.getInt("coins", 8_450_000); set(v) = prefs.edit().putInt("coins", v.coerceAtLeast(0)).apply()
    var spins: Int get() = prefs.getInt("spins", STARTING_SPINS).coerceIn(0, MAX_SPINS); set(v) = prefs.edit().putInt("spins", v.coerceIn(0, MAX_SPINS)).apply()
    var xp: Int get() = prefs.getInt("xp", 560); set(v) = prefs.edit().putInt("xp", v.coerceAtLeast(0)).apply()
    var lastSpinRecharge: Long get() = prefs.getLong("last_spin_recharge", System.currentTimeMillis()); set(v) = prefs.edit().putLong("last_spin_recharge", v).apply()
    var soundEnabled: Boolean get() = prefs.getBoolean("sound_enabled", true); set(v) = prefs.edit().putBoolean("sound_enabled", v).apply()
}

@Composable
private fun FrontlineApp() {
    val context = LocalContext.current
    val store = remember { GameStore(context) }
    val sound = remember { GameSound(context) }
    var tab by rememberSaveable { mutableStateOf(GameTab.SLOT) }
    var coins by remember { mutableIntStateOf(store.coins) }
    var spins by remember { mutableIntStateOf(store.spins) }
    var xp by remember { mutableIntStateOf(store.xp) }
    var spinning by remember { mutableStateOf(false) }
    var rechargeSeconds by remember { mutableIntStateOf(0) }
    var selectedMultiplier by rememberSaveable { mutableIntStateOf(1) }
    var lastMultiplier by rememberSaveable { mutableIntStateOf(0) }
    var lastWinCoins by rememberSaveable { mutableIntStateOf(0) }
    var message by rememberSaveable { mutableStateOf("PRONTO AL LANCIO, COMANDANTE!") }
    var lastResult by rememberSaveable { mutableStateOf("") }
    var soundEnabled by remember { mutableStateOf(store.soundEnabled) }
    var reels by remember { mutableStateOf(listOf("🪖", "🎖️", "🚁")) }

    val scope = rememberCoroutineScope()
    val effectiveBet = 100_000 * selectedMultiplier

    fun persist() {
        store.coins = coins
        store.spins = spins
        store.xp = xp
        store.soundEnabled = soundEnabled
    }

    DisposableEffect(Unit) { onDispose { sound.release() } }
    LaunchedEffect(soundEnabled) { sound.setEnabled(soundEnabled) }

    LaunchedEffect(Unit) {
        while (true) {
            if (spins >= MAX_SPINS) {
                rechargeSeconds = 0
            } else {
                val elapsed = max(0L, System.currentTimeMillis() - store.lastSpinRecharge)
                val gained = (elapsed / SPIN_RECHARGE_MS).toInt()
                if (gained > 0) {
                    val actual = minOf(gained, MAX_SPINS - spins)
                    spins += actual
                    store.lastSpinRecharge += actual * SPIN_RECHARGE_MS
                    persist()
                }
                val remaining = max(0L, SPIN_RECHARGE_MS - max(0L, System.currentTimeMillis() - store.lastSpinRecharge))
                rechargeSeconds = (remaining / 1000L).toInt()
            }
            delay(1000)
        }
    }

    LaunchedEffect(spinning) {
        if (!spinning) return@LaunchedEffect
        // The three visible reels are animated independently by AnimatedReel.
        // This coroutine only waits for the longest reel before calculating the result.
        delay(2550)
        val final = List(3) { slotSymbols.random().icon }
        reels = final
        val first = final[0]
        val second = final[1]
        val third = final[2]
        val triple = first == second && second == third
        val pair = first == second || second == third || first == third

        when {
            triple -> {
                val ruleMultiplier = winRules.firstOrNull { it.symbol == first }?.multiplier ?: 2
                val gain = effectiveBet * ruleMultiplier
                lastMultiplier = ruleMultiplier
                lastWinCoins = gain
                lastResult = "$first  $second  $third"
                coins += gain
                xp += 25 * ruleMultiplier
                message = "🏆 VITTORIA! +${compactNumber(gain)}"
                if (soundEnabled) sound.win()
            }
            pair -> {
                val gain = effectiveBet * 2
                lastMultiplier = 2
                lastWinCoins = gain
                lastResult = "$first  $second  $third"
                coins += gain
                xp += 15
                message = "🎯 DOPPIA! +${compactNumber(gain)}"
                if (soundEnabled) sound.win()
            }
            else -> {
                lastMultiplier = 0
                lastWinCoins = 0
                lastResult = "$first  $second  $third"
                xp += 5
                message = "NESSUNA COMBINAZIONE"
                if (soundEnabled) sound.lose()
            }
        }
        persist()
        spinning = false
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Olive, background = Sky)) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF14210D), tonalElevation = 0.dp) {
                    GameTab.values().forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item; if (soundEnabled) sound.tap() },
                            icon = { Text(tabIcon(item), fontSize = if (tab == item) 25.sp else 21.sp) },
                            label = { Text(tabLabel(item), fontSize = 8.sp, fontWeight = FontWeight.Black) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                Modifier.fillMaxSize().padding(padding).background(
                    Brush.verticalGradient(listOf(Sky, Color(0xFF8AB86C), Grass, Color(0xFF1C2B14)))
                )
            ) {
                when (tab) {
                    GameTab.SLOT -> SlotScreen(
                        xp = xp, coins = coins, spins = spins, rechargeSeconds = rechargeSeconds,
                        soundEnabled = soundEnabled, onSound = {
                            soundEnabled = !soundEnabled
                            persist()
                            if (soundEnabled) sound.tap()
                        }, reels = reels, spinning = spinning, selectedMultiplier = selectedMultiplier,
                        lastMultiplier = lastMultiplier, lastResult = lastResult, lastWinCoins = lastWinCoins,
                        message = message, onMultiplier = { selectedMultiplier = it },
                        onSpin = {
                            if (!spinning && spins > 0 && coins >= effectiveBet) {
                                spinning = true
                                if (spins == MAX_SPINS) store.lastSpinRecharge = System.currentTimeMillis()
                                spins--
                                coins -= effectiveBet
                                lastMultiplier = 0
                                lastWinCoins = 0
                                lastResult = ""
                                message = "I TRE RULLI SONO IN MOVIMENTO..."
                                persist()
                                if (soundEnabled) sound.spin()
                            }
                        }
                    )
                    GameTab.SHOP -> SimpleScreen("📦", "NEGOZIO", "Rifornimenti del Comandante", listOf("Cassa munizioni" to "500 🪙", "Pacchetto corazzato" to "1.500 🪙", "Kit speciale" to "3.000 🪙"))
                    GameTab.CARDS -> SimpleScreen("🃏", "CARTE", "Collezione tattica", listOf("Ranger" to "Livello 3", "Pilota" to "Livello 4", "Artigliere" to "Livello 2"))
                    GameTab.BASE -> SimpleScreen("🏠", "BASE", "Potenzia il quartier generale", listOf("Comando" to "Livello 5", "Officina" to "+ produzione", "Radar" to "+ raid"))
                    GameTab.ALLIANCE -> SimpleScreen("🛡️", "ALLEANZA", "La tua squadra", listOf("Squadra Alpha" to "12 membri", "Difesa" to "86%", "Prossima missione" to "18 min"))
                }
            }
        }
    }
}

private fun tabLabel(tab: GameTab) = when (tab) {
    GameTab.SHOP -> "NEGOZIO"; GameTab.CARDS -> "CARTE"; GameTab.SLOT -> "SLOT"; GameTab.BASE -> "BASE"; GameTab.ALLIANCE -> "ALLEANZA"
}
private fun tabIcon(tab: GameTab) = when (tab) {
    GameTab.SHOP -> "📦"; GameTab.CARDS -> "🃏"; GameTab.SLOT -> "🎰"; GameTab.BASE -> "🏠"; GameTab.ALLIANCE -> "🛡️"
}

@Composable
private fun SlotScreen(
    xp: Int, coins: Int, spins: Int, rechargeSeconds: Int, soundEnabled: Boolean, onSound: () -> Unit,
    reels: List<String>, spinning: Boolean, selectedMultiplier: Int, lastMultiplier: Int, lastResult: String,
    lastWinCoins: Int, message: String, onMultiplier: (Int) -> Unit, onSpin: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 7.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TopBar(xp, coins, soundEnabled, onSound)
        WinningBoard()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.width(72.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                MiniSideCard("🎁", "MISSIONI", "2")
                MiniSideCard("🏆", "CLASSIFICA", "2g 14h")
                MiniSideCard("🎁", "RICOMPENSE", "14h")
            }
            SlotMachine(
                reels = reels, spinning = spinning, selectedMultiplier = selectedMultiplier,
                lastMultiplier = lastMultiplier, lastResult = lastResult, lastWinCoins = lastWinCoins,
                message = message, onMultiplierChange = onMultiplier, onSpin = onSpin, modifier = Modifier.weight(1f)
            )
            Column(Modifier.width(82.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SideEvent("⚡", "OPERAZIONE FULMINE", "2g 14h", Purple, Modifier.fillMaxWidth().height(145.dp))
                SideEvent("🎁", "BONUS GIORNALIERO", "14h", Blue, Modifier.fillMaxWidth().height(120.dp))
                SideEvent("▶", "VIDEO BONUS", "+10", Color(0xFF28618A), Modifier.fillMaxWidth().height(104.dp))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SpinCounter(spins, rechargeSeconds, Modifier.weight(1f))
            SuperSpinCard(Modifier.weight(1f))
        }
    }
}

@Composable
private fun TopBar(xp: Int, coins: Int, soundEnabled: Boolean, onSound: () -> Unit) {
    Row(Modifier.fillMaxWidth().shadow(7.dp, RoundedCornerShape(19.dp)).clip(RoundedCornerShape(19.dp)).background(OliveDark).border(2.dp, Color(0xFF667943), RoundedCornerShape(19.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(15.dp)).background(Gold).border(2.dp, GoldDark, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text("🪖", fontSize = 30.sp) }
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Text("FRONTLINE COMMANDER", color = White, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("LV. 23", color = Gold, fontWeight = FontWeight.Black, fontSize = 9.sp); Spacer(Modifier.width(6.dp)); Text("$xp / 1200 XP", color = White, fontSize = 8.sp, fontWeight = FontWeight.Bold) }
        }
        ResourcePill("🪙", compactNumber(coins)); Spacer(Modifier.width(3.dp)); ResourcePill("💎", "1.250")
        Text(if (soundEnabled) "🔊" else "🔇", Modifier.clickable { onSound() }.padding(4.dp), fontSize = 16.sp)
    }
}

@Composable
private fun ResourcePill(icon: String, value: String) {
    Row(Modifier.clip(RoundedCornerShape(11.dp)).background(Color(0xFF66773C)).border(1.dp, Color(0xFF8D9B5A), RoundedCornerShape(11.dp)).padding(horizontal = 4.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 13.sp); Spacer(Modifier.width(2.dp)); Text(value, color = White, fontWeight = FontWeight.ExtraBold, fontSize = 8.sp); Text("+", color = White, fontWeight = FontWeight.Black, fontSize = 11.sp, modifier = Modifier.padding(start = 2.dp))
    }
}

@Composable
private fun WinningBoard() {
    Card(Modifier.fillMaxWidth().shadow(7.dp, RoundedCornerShape(20.dp)), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = OlivePanel), border = BorderStroke(3.dp, Color(0xFF707A4D))) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 8.dp)) {
            Text("COMBINAZIONI VINCENTI", color = White, fontWeight = FontWeight.Black, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) { winRules.take(4).forEach { WinLine(it) } }
                Column(Modifier.weight(1f)) { winRules.drop(4).forEach { WinLine(it) } }
            }
            Text("ⓘ  Le vincite vengono moltiplicate sulla puntata totale", color = Color(0xFFD8DDC8), fontSize = 8.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun WinLine(rule: WinRule) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${rule.symbol} ${rule.symbol} ${rule.symbol}", color = White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text("×${rule.multiplier}", color = Gold, fontWeight = FontWeight.Black, fontSize = 13.sp)
    }
}

@Composable
private fun SlotMachine(
    reels: List<String>, spinning: Boolean, selectedMultiplier: Int, lastMultiplier: Int, lastResult: String,
    lastWinCoins: Int, message: String, onMultiplierChange: (Int) -> Unit, onSpin: () -> Unit, modifier: Modifier
) {
    Box(modifier.shadow(12.dp, RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp)).background(Metal).border(5.dp, MetalDark, RoundedCornerShape(28.dp))) {
        Column(Modifier.fillMaxWidth().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFF77795B), Color(0xFF3A3D2E)))).border(3.dp, MetalLight, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                Text("⚔  FRONTLINE  ⚔\nCOMMANDER", color = Cream, fontWeight = FontWeight.Black, fontSize = 16.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
            }
            Spacer(Modifier.height(7.dp))
            Box(Modifier.fillMaxWidth().height(315.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF141710)).border(7.dp, Color(0xFF2D3025), RoundedCornerShape(22.dp)).padding(6.dp)) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    reels.forEachIndexed { index, icon -> AnimatedReel(icon, spinning, index, Modifier.weight(1f).fillMaxHeight()) }
                }
                Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0xFF6F6A51)).align(Alignment.Center))
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                InfoBox("PUNTATA TOTALE", compactNumber(100_000 * selectedMultiplier), Modifier.weight(1f))
                MultiplierBox(selectedMultiplier, onMultiplierChange, Modifier.weight(1.05f))
            }
            Text(if (spinning) "I TRE RULLI STANNO GIRANDO..." else message, color = Gold, fontWeight = FontWeight.Black, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
            if (!spinning && lastMultiplier > 0) Text("$lastResult  •  +${compactNumber(lastWinCoins)} 🪙", color = White, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Button(onClick = onSpin, enabled = !spinning, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = White, disabledContainerColor = RedDark), modifier = Modifier.fillMaxWidth().height(88.dp), shape = RoundedCornerShape(21.dp), border = BorderStroke(4.dp, RedDark)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(if (spinning) "GIRANDO..." else "SPIN", fontSize = 32.sp, fontWeight = FontWeight.Black); if (!spinning) Text("Tocca per avviare i tre rulli", fontSize = 7.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun AnimatedReel(finalIcon: String, spinning: Boolean, index: Int, modifier: Modifier) {
    var shown by remember { mutableStateOf(finalIcon) }
    val travel = remember { Animatable(0f) }
    val random = remember(index) { Random(index + 1000) }

    LaunchedEffect(spinning) {
        if (!spinning) {
            shown = finalIcon
            travel.snapTo(0f)
            return@LaunchedEffect
        }
        delay(index * 120L)
        val stopAt = 1500L + index * 420L
        val started = System.currentTimeMillis()
        while (System.currentTimeMillis() - started < stopAt) {
            shown = slotSymbols[random.nextInt(slotSymbols.size)].icon
            travel.snapTo(-58f)
            travel.animateTo(0f, tween(90))
            delay(25)
        }
        shown = finalIcon
        travel.animateTo(0f, tween(160))
    }

    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Cream).border(3.dp, Color(0xFF24251C), RoundedCornerShape(16.dp)).clipToBounds(), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
            Text(slotSymbols[(index + 2) % slotSymbols.size].icon, fontSize = 30.sp)
            Box(Modifier.fillMaxWidth().height(96.dp).clipToBounds(), contentAlignment = Alignment.Center) {
                AnimatedContent(targetState = shown, transitionSpec = {
                    (slideInVertically(tween(70)) { -it } + fadeIn(tween(40))).togetherWith(slideOutVertically(tween(70)) { it } + fadeOut(tween(40)))
                }, label = "reel_$index") { value -> Text(value, fontSize = 48.sp, modifier = Modifier.offset(y = travel.value.dp)) }
            }
            Text(slotSymbols[(index + 5) % slotSymbols.size].icon, fontSize = 30.sp)
        }
    }
}

@Composable
private fun InfoBox(title: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(OliveDark).border(1.dp, Color(0xFF647344), RoundedCornerShape(14.dp)).padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color(0xFFC8CDBB), fontSize = 7.sp, fontWeight = FontWeight.Bold); Text(value, color = White, fontSize = 14.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun MultiplierBox(selected: Int, onChange: (Int) -> Unit, modifier: Modifier) {
    Row(modifier.clip(RoundedCornerShape(14.dp)).background(OliveDark).border(1.dp, Color(0xFF647344), RoundedCornerShape(14.dp)).padding(horizontal = 3.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("−", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected - 1).coerceAtLeast(1)) }.padding(horizontal = 4.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("MOLTIPLICATORE", color = Color(0xFFC8CDBB), fontSize = 6.sp, fontWeight = FontWeight.Bold); Text("X$selected", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Black) }
        Text("+", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected + 1).coerceAtMost(5)) }.padding(horizontal = 4.dp))
    }
}

@Composable
private fun MiniSideCard(icon: String, title: String, value: String) {
    Card(Modifier.fillMaxWidth().height(104.dp).shadow(5.dp, RoundedCornerShape(15.dp)), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = OliveDark), border = BorderStroke(2.dp, Color(0xFF6B7947))) {
        Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text(icon, fontSize = 27.sp); Text(title, color = White, fontSize = 7.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center); Text(value, color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun SpinCounter(spins: Int, rechargeSeconds: Int, modifier: Modifier) {
    Card(modifier.height(82.dp).shadow(5.dp, RoundedCornerShape(17.dp)), shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = OliveDark), border = BorderStroke(2.dp, Color(0xFF647344))) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("GIRI DISPONIBILI", color = White, fontSize = 8.sp, fontWeight = FontWeight.Black)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("🪖", fontSize = 22.sp); Text("$spins", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black); Text("/100", color = White, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
            Text(if (spins >= MAX_SPINS) "CAPACITÀ MASSIMA" else "+1 GIRO TRA ${rechargeSeconds / 60}:${(rechargeSeconds % 60).toString().padStart(2, '0')}", color = White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SuperSpinCard(modifier: Modifier) {
    Card(modifier.height(82.dp).shadow(5.dp, RoundedCornerShape(17.dp)), shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Blue), border = BorderStroke(2.dp, Color(0xFF6EB9E0))) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text("🚀", fontSize = 25.sp); Text("SUPER SPIN", color = White, fontWeight = FontWeight.Black, fontSize = 13.sp); Text("ATTIVO", color = Gold, fontWeight = FontWeight.Black, fontSize = 9.sp) }
    }
}

@Composable
private fun SideEvent(icon: String, title: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier.shadow(6.dp, RoundedCornerShape(15.dp)), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = color), border = BorderStroke(2.dp, Color(0xFF6F7C62))) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text(icon, fontSize = 28.sp); Text(title, color = White, fontWeight = FontWeight.Black, fontSize = 8.sp, textAlign = TextAlign.Center); Text(value, color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp) }
    }
}

@Composable
private fun SimpleScreen(icon: String, title: String, subtitle: String, rows: List<Pair<String, String>>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = OliveDark), border = BorderStroke(3.dp, Color(0xFF6E7D49))) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(64.dp).clip(RoundedCornerShape(18.dp)).background(Gold), contentAlignment = Alignment.Center) { Text(icon, fontSize = 38.sp) }
                Spacer(Modifier.width(12.dp))
                Column { Text(title, color = White, fontSize = 27.sp, fontWeight = FontWeight.Black); Text(subtitle, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
        }
        rows.forEach { (name, detail) ->
            Card(Modifier.fillMaxWidth().clickable { }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE7E5C9)), border = BorderStroke(2.dp, Color(0xFF6B744F))) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("▣", color = Olive, fontSize = 25.sp, fontWeight = FontWeight.Black); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, color = Ink(), fontSize = 18.sp, fontWeight = FontWeight.Black); Text(detail, color = Color(0xFF4F5A43), fontSize = 11.sp) }; Text("›", color = Olive, fontSize = 30.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

private fun Ink() = Color(0xFF202419)

private fun compactNumber(value: Int): String = when {
    value >= 1_000_000 -> "${value / 1_000_000}.${(value / 100_000) % 10}M"
    value >= 1_000 -> "${value / 1_000}.${(value / 100) % 10}K"
    else -> value.toString()
}

private class GameSound(context: Context) {
    private val pool: SoundPool
    private val music: MediaPlayer?
    private val spinId: Int
    private val winId: Int
    private val loseId: Int
    private val tapId: Int
    private var enabled = true

    init {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        pool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(4).build()
        spinId = pool.load(context, R.raw.slot_spin, 1)
        winId = pool.load(context, R.raw.slot_win, 1)
        loseId = pool.load(context, R.raw.slot_lose, 1)
        tapId = pool.load(context, R.raw.slot_tap, 1)
        music = MediaPlayer.create(context, R.raw.frontline_music)?.apply { isLooping = true; setVolume(0.16f, 0.16f) }
    }
    fun setEnabled(value: Boolean) { enabled = value; if (enabled) { if (music?.isPlaying == false) music.start() } else if (music?.isPlaying == true) music.pause() }
    fun spin() { if (enabled) pool.play(spinId, .55f, .55f, 1, 0, 1f) }
    fun win() { if (enabled) pool.play(winId, .75f, .75f, 1, 0, 1.05f) }
    fun lose() { if (enabled) pool.play(loseId, .4f, .4f, 1, 0, .9f) }
    fun tap() { if (enabled) pool.play(tapId, .25f, .25f, 1, 0, 1.2f) }
    fun release() { if (music?.isPlaying == true) music.stop(); music?.release(); pool.release() }
}
