package com.frontline.commander

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private val SkyTop = Color(0xFF76A98A)
private val SkyBottom = Color(0xFF355C35)
private val Olive950 = Color(0xFF0C1208)
private val Olive900 = Color(0xFF151D0D)
private val Olive800 = Color(0xFF263416)
private val Olive700 = Color(0xFF3E4E21)
private val Olive600 = Color(0xFF5D6D31)
private val Gold = Color(0xFFFFD447)
private val Gold2 = Color(0xFFB57E18)
private val Cream = Color(0xFFFFF3D0)
private val Red = Color(0xFFD9432E)
private val Blue = Color(0xFF126AA1)
private val Purple = Color(0xFF673A9B)
private val Steel = Color(0xFF56616A)

private enum class Symbol { HELMET, MEDAL, HELI, TANK, CRATE, GRENADE, JET, STAR }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrontlineApp() }
    }
}

@Composable
fun FrontlineApp() {
    var tab by remember { mutableStateOf(2) }
    var coins by remember { mutableStateOf(8450000) }
    var gems by remember { mutableStateOf(1250) }
    var bet by remember { mutableStateOf(100000) }
    var spins by remember { mutableStateOf(17) }
    var multiplier by remember { mutableStateOf(1) }
    var spinning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("PRONTO ALLO SPIN") }
    var reels by remember { mutableStateOf(listOf(Symbol.HELMET, Symbol.MEDAL, Symbol.HELI)) }

    MaterialTheme(colorScheme = darkColorScheme(background = Olive950, primary = Gold)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(SkyTop, SkyBottom, Olive900, Olive950))
            )
        ) {
            LandscapeBackground()
            Column(Modifier.fillMaxSize()) {
                TopBar(coins, gems)
                if (tab == 2) {
                    SlotHome(
                        reels, bet, spins, multiplier, spinning, result,
                        onSpin = {
                            if (!spinning && spins > 0) {
                                spinning = true
                                spins--
                                val next = List(3) {
                                    Symbol.values().random()
                                }
                                reels = next
                                val win = next.distinct().size == 1
                                multiplier = if (win) when (next[0]) {
                                    Symbol.STAR -> 50
                                    Symbol.GRENADE -> 30
                                    Symbol.CRATE -> 20
                                    Symbol.TANK -> 15
                                    Symbol.HELI -> 10
                                    else -> 2
                                } else 1
                                result = if (win) "COMBINAZIONE VINCENTE!  +${"%,d".format(bet * multiplier)}" else "NESSUNA COMBINAZIONE"
                                if (win) coins += bet * multiplier
                                spinning = false
                            }
                        },
                        onMinus = { bet = (bet - 10000).coerceAtLeast(10000) },
                        onPlus = { bet = (bet + 10000).coerceAtMost(coins.coerceAtLeast(10000)) }
                    )
                } else {
                    PlaceholderSection(tab)
                }
                Spacer(Modifier.weight(1f))
                BottomNav(tab) { tab = it }
            }
        }
    }
}

@Composable
private fun LandscapeBackground() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        // distant hills
        val hill = Path().apply {
            moveTo(0f, h * .29f)
            quadraticBezierTo(w*.18f, h*.20f, w*.34f, h*.30f)
            quadraticBezierTo(w*.52f, h*.18f, w*.68f, h*.29f)
            quadraticBezierTo(w*.83f, h*.19f, w, h*.28f)
            lineTo(w, h*.48f); lineTo(0f, h*.48f); close()
        }
        drawPath(hill, brush = SolidColor(Color(0xFF55754C)))
        // trees
        for (i in 0..15) {
            val x = (i / 15f) * w
            val y = h * (.39f + (i % 3) * .018f)
            drawCircle(Color(0xFF294A2A), 28f, Offset(x, y))
            drawCircle(Color(0xFF3D6135), 22f, Offset(x+12f, y-12f))
            drawRect(Color(0xFF4B3820), Offset(x-4f, y+12f), Size(8f, 35f))
        }
        // road / base strip
        drawRect(Color(0xFF6A6548), Offset(0f, h*.73f), Size(w, h*.27f))
        drawRect(Color(0xFF4D5037), Offset(0f, h*.77f), Size(w, h*.23f))
    }
}

@Composable
private fun TopBar(coins: Int, gems: Int) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PanelIcon(56.dp) { HelmetIcon() }
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text("COMMANDER", color = Color.White.copy(.72f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("23", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(6.dp))
                Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(.45f))) {
                    Box(Modifier.fillMaxWidth(.47f).fillMaxHeight().background(Gold))
                }
            }
            Text("560 / 1200 XP", color = Color.White.copy(.72f), fontSize = 7.sp)
        }
        CurrencyPill("COINS", "%,d".format(coins), Color(0xFFC08B24))
        Spacer(Modifier.width(4.dp))
        CurrencyPill("GEMS", "%,d".format(gems), Color(0xFFD05CBA))
        Spacer(Modifier.width(4.dp))
        PanelIcon(46.dp) { Text("☰", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun PanelIcon(size: androidx.compose.ui.unit.Dp, content: @Composable () -> Unit) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(15.dp))
            .background(Brush.verticalGradient(listOf(Olive700, Olive800)))
            .border(2.dp, Gold2, RoundedCornerShape(15.dp)),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun CurrencyPill(label: String, value: String, accent: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF12170E).copy(.94f))
            .border(1.dp, accent, RoundedCornerShape(12.dp))
            .padding(horizontal = 7.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (label == "COINS") "●" else "◆", color = accent, fontSize = 12.sp)
        Spacer(Modifier.width(3.dp))
        Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(2.dp))
        Text("+", color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun SlotHome(
    reels: List<Symbol>, bet: Int, spins: Int, multiplier: Int, spinning: Boolean, result: String,
    onSpin: () -> Unit, onMinus: () -> Unit, onPlus: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WinningTable()
        Spacer(Modifier.height(6.dp))
        MachineTitle()
        SlotMachine(reels, spinning)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            InfoCard("PUNTATA TOTALE", "%,d".format(bet), Modifier.weight(1f), onMinus, onPlus)
            InfoCard("MOLTIPLICATORE", "X$multiplier", Modifier.weight(1f))
        }
        Text(result, color = if (multiplier > 1) Gold else Color.White.copy(.8f), fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            SideCard("GIRI DISPONIBILI", "$spins", Modifier.weight(1f), Olive800) {
                HelmetIcon()
            }
            Button(
                onClick = onSpin,
                enabled = !spinning && spins > 0,
                modifier = Modifier.weight(1.75f).height(88.dp),
                shape = RoundedCornerShape(22.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Color(0xFF6B2A22)),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (spinning) "..." else "SPIN", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.Black)
                    Text("Tieni premuto per SPIN automatici", color = Color.White.copy(.82f), fontSize = 7.sp)
                }
            }
            SideCard("SUPER SPIN", "ATTIVO", Modifier.weight(1f), Blue) {
                RocketIcon()
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SideCard("OPERAZIONE FULMINE", "2g 14h", Modifier.weight(1f), Purple) { TankIcon() }
            SideCard("BONUS GIORNALIERO", "14h", Modifier.weight(1f), Blue) { CrateIcon() }
            SideCard("VIDEO BONUS", "+10", Modifier.weight(1f), Color(0xFF285A7E)) { PlayIcon() }
        }
        Spacer(Modifier.height(7.dp))
    }
}

@Composable
private fun MachineTitle() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("◀", color = Gold, fontSize = 19.sp)
            Spacer(Modifier.width(4.dp))
            Text("FRONTLINE", color = Color(0xFFE7E5D6), fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Spacer(Modifier.width(4.dp))
            Text("▶", color = Gold, fontSize = 19.sp)
        }
        Text("COMMANDER", color = Color(0xFFFFA800), fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun WinningTable() {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel.copy(.97f)),
        border = androidx.compose.foundation.BorderStroke(2.dp, Gold2)
    ) {
        Column(Modifier.padding(7.dp)) {
            Text("COMBINAZIONI VINCENTI", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Cream, fontSize = 14.sp, fontWeight = FontWeight.Black)
            val rows = listOf(
                Symbol.HELMET to 2, Symbol.MEDAL to 3, Symbol.CRATE to 4,
                Symbol.GRENADE to 6, Symbol.HELI to 10, Symbol.TANK to 15,
                Symbol.JET to 20, Symbol.STAR to 50
            )
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    rows.take(4).forEach { PrizeRow(it.first, it.second) }
                }
                Column(Modifier.weight(1f)) {
                    rows.drop(4).forEach { PrizeRow(it.first, it.second) }
                }
            }
            Text("ⓘ Le vincite vengono moltiplicate per la tua puntata totale", color = Color.White.copy(.62f), fontSize = 8.sp)
        }
    }
}

@Composable
private fun PrizeRow(symbol: Symbol, mult: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) { SymbolArt(symbol, 23.dp) }
        Text("×", color = Color.White.copy(.6f), fontSize = 12.sp)
        Text("3", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.weight(1f))
        Text("x$mult", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun SlotMachine(reels: List<Symbol>, spinning: Boolean) {
    val scale by animateFloatAsState(if (spinning) .985f else 1f, label = "machine")
    Box(
        Modifier.fillMaxWidth().scale(scale).padding(vertical = 4.dp)
            .clip(RoundedCornerShape(27.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF79804A), Olive700, Color(0xFF202717))))
            .border(5.dp, Gold2, RoundedCornerShape(27.dp))
            .padding(9.dp)
    ) {
        Box(
            Modifier.fillMaxWidth().height(260.dp)
                .clip(RoundedCornerShape(19.dp))
                .background(Color(0xFF10130D))
                .border(3.dp, Color(0xFF10150B), RoundedCornerShape(19.dp))
                .padding(5.dp)
        ) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                reels.forEach { symbol ->
                    Box(
                        Modifier.weight(1f).fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.verticalGradient(listOf(Color(0xFFFFF8DF), Cream, Color(0xFFE2D5AD))))
                            .border(2.dp, Color(0xFF3A3928), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) { SymbolArt(symbol, 82.dp) }
                }
            }
            Box(Modifier.align(Alignment.CenterStart).width(9.dp).height(48.dp).clip(RoundedCornerShape(5.dp)).background(Gold))
            Box(Modifier.align(Alignment.CenterEnd).width(9.dp).height(48.dp).clip(RoundedCornerShape(5.dp)).background(Gold))
        }
        // side handle
        Box(
            Modifier.align(Alignment.CenterEnd).offset(x = 16.dp).size(30.dp)
                .clip(RoundedCornerShape(50)).background(Color(0xFF8C1F17))
                .border(3.dp, Color(0xFFCE4B34), RoundedCornerShape(50))
        )
    }
}

@Composable
private fun InfoCard(title: String, value: String, modifier: Modifier, minus: (() -> Unit)? = null, plus: (() -> Unit)? = null) {
    Card(modifier.height(68.dp), colors = CardDefaults.cardColors(containerColor = Olive800), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(title, color = Color.White.copy(.58f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (minus != null) SmallButton("−", minus)
                Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 7.dp))
                if (plus != null) SmallButton("+", plus)
            }
        }
    }
}

@Composable
private fun SmallButton(text: String, action: () -> Unit) {
    Box(Modifier.size(25.dp).clip(RoundedCornerShape(7.dp)).background(Gold).clickable { action() }, contentAlignment = Alignment.Center) {
        Text(text, color = Olive950, fontSize = 18.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun SideCard(title: String, value: String, modifier: Modifier, bg: Color, art: @Composable () -> Unit) {
    Card(modifier.height(82.dp), colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) { art() }
            Text(title, color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, maxLines = 2)
            Text(value, color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val labels = listOf("NEGOZIO", "CARTE", "SLOT", "BASE", "ALLEANZA")
    Row(Modifier.fillMaxWidth().background(Color(0xFF11160D).copy(.98f)).padding(horizontal = 3.dp, vertical = 5.dp)) {
        labels.forEachIndexed { i, label ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).clickable { onSelect(i) }
                    .background(if (i == selected) Color(0xFFB98A25).copy(.24f) else Color.Transparent)
                    .padding(vertical = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) {
                    when (i) {
                        0 -> CrateIcon()
                        1 -> CardIcon()
                        2 -> ReelIcon()
                        3 -> BaseIcon()
                        else -> ShieldIcon()
                    }
                }
                Text(label, color = if (i == selected) Gold else Color.White.copy(.58f), fontSize = 7.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun PlaceholderSection(selected: Int) {
    Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel.copy(.96f)), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SEZIONE IN SVILUPPO", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("La schermata principale è pronta: usa SLOT per giocare.", color = Color.White.copy(.75f), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun SymbolArt(symbol: Symbol, size: androidx.compose.ui.unit.Dp) {
    Canvas(Modifier.size(size)) {
        val s = minOf(size.toPx(), size.toPx())
        when (symbol) {
            Symbol.HELMET -> HelmetIconDraw(this, s)
            Symbol.MEDAL -> MedalIconDraw(this, s)
            Symbol.HELI -> HeliIconDraw(this, s)
            Symbol.TANK -> TankIconDraw(this, s)
            Symbol.CRATE -> CrateIconDraw(this, s)
            Symbol.GRENADE -> GrenadeIconDraw(this, s)
            Symbol.JET -> JetIconDraw(this, s)
            Symbol.STAR -> StarIconDraw(this, s)
        }
    }
}

@Composable private fun HelmetIcon() { Canvas(Modifier.fillMaxSize(.75f)) { HelmetIconDraw(this, size.minDimension) } }
@Composable private fun TankIcon() { Canvas(Modifier.fillMaxSize(.82f)) { TankIconDraw(this, size.minDimension) } }
@Composable private fun CrateIcon() { Canvas(Modifier.fillMaxSize(.82f)) { CrateIconDraw(this, size.minDimension) } }
@Composable private fun RocketIcon() { Canvas(Modifier.fillMaxSize(.82f)) { RocketIconDraw(this, size.minDimension) } }
@Composable private fun PlayIcon() { Canvas(Modifier.fillMaxSize(.82f)) { PlayIconDraw(this, size.minDimension) } }
@Composable private fun CardIcon() { Canvas(Modifier.fillMaxSize(.82f)) { CardIconDraw(this, size.minDimension) } }
@Composable private fun ReelIcon() { Canvas(Modifier.fillMaxSize(.82f)) { ReelIconDraw(this, size.minDimension) } }
@Composable private fun BaseIcon() { Canvas(Modifier.fillMaxSize(.82f)) { BaseIconDraw(this, size.minDimension) } }
@Composable private fun ShieldIcon() { Canvas(Modifier.fillMaxSize(.82f)) { ShieldIconDraw(this, size.minDimension) } }

private fun HelmetIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val cx = s/2; val cy = s*.53f
    c.drawOval(Rect(cx-s*.42f, cy-s*.26f, cx+s*.42f, cy+s*.20f), Color(0xFF4F6428))
    c.drawArc(Rect(cx-s*.46f, cy-s*.38f, cx+s*.46f, cy+s*.32f), 180f, 180f, false, Color(0xFF75883A), Stroke(s*.12f))
    c.drawRect(cx-s*.34f, cy+s*.03f, cx+s*.34f, cy+s*.25f, Color(0xFF34451C))
    c.drawCircle(cx+s*.20f, cy-s*.16f, s*.055f, Gold)
}

private fun MedalIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val cx=s/2; val top=s*.08f
    c.drawRect(cx-s*.14f, top, cx-s*.02f, s*.42f, Color(0xFF174E8B))
    c.drawRect(cx+s*.02f, top, cx+s*.14f, s*.42f, Color(0xFFD8423A))
    c.drawCircle(cx, s*.60f, s*.27f, Gold)
    c.drawCircle(cx, s*.60f, s*.19f, Color(0xFFFFE58A), Stroke(s*.045f))
    StarIconDraw(c, s*.28f, Offset(cx, s*.60f), Color(0xFFD89E21))
}

private fun HeliIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val cx=s*.52f; val cy=s*.55f
    c.drawOval(Rect(cx-s*.36f,cy-s*.16f,cx+s*.30f,cy+s*.16f), Color(0xFF536A2B))
    c.drawOval(Rect(cx-s*.22f,cy-s*.10f,cx+s*.16f,cy+s*.08f), Color(0xFFB6D0C8))
    c.drawRect(cx-s*.08f, cy-s*.31f, cx+s*.08f, cy-s*.18f, Color(0xFF3E4E20))
    c.drawLine(cx-s*.52f,cy-s*.25f,cx+s*.45f,cy-s*.25f, Color(0xFF20281A), s*.055f)
    c.drawLine(cx+s*.25f,cy, cx+s*.52f,cy-s*.05f, Color(0xFF3C4D20), s*.07f)
    c.drawCircle(cx+s*.53f,cy-s*.05f,s*.06f, Color(0xFFB83226))
}

private fun TankIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val y=s*.61f
    c.drawCircle(s*.25f,y,s*.13f,Color(0xFF1D2816)); c.drawCircle(s*.75f,y,s*.13f,Color(0xFF1D2816))
    c.drawRect(s*.12f,y-s*.11f,s*.88f,y+s*.11f,Color(0xFF34451C))
    c.drawRoundRect(RoundRect(Rect(s*.26f,s*.38f,s*.72f,s*.64f),s*.06f),Color(0xFF71833A))
    c.drawRect(s*.58f,s*.30f,s*.92f,s*.36f,Color(0xFF3A4A20))
    c.drawCircle(s*.49f,s*.45f,s*.10f,Color(0xFF53672A))
}

private fun CrateIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val r=Rect(s*.18f,s*.20f,s*.82f,s*.82f)
    c.drawRoundRect(RoundRect(r,s*.06f),Color(0xFF8A6A2A))
    c.drawLine(s*.25f,s*.27f,s*.75f,s*.75f,Color(0xFFCFB65A),s*.05f)
    c.drawLine(s*.75f,s*.27f,s*.25f,s*.75f,Color(0xFFCFB65A),s*.05f)
    c.drawRect(s*.28f,s*.28f,s*.72f,s*.34f,Color(0xFF5A431C))
    c.drawRect(s*.28f,s*.66f,s*.72f,s*.72f,Color(0xFF5A431C))
}

private fun GrenadeIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val cx=s*.5f
    c.drawCircle(cx,s*.58f,s*.28f,Color(0xFF4A5A24))
    c.drawRect(cx-s*.10f,s*.18f,cx+s*.10f,s*.33f,Color(0xFF273317))
    c.drawLine(cx+s*.08f,s*.20f,cx+s*.24f,s*.10f,Color(0xFFD4B54A),s*.035f)
}

private fun JetIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val p=Path().apply {
        moveTo(s*.85f,s*.50f); lineTo(s*.58f,s*.43f); lineTo(s*.30f,s*.12f); lineTo(s*.36f,s*.47f)
        lineTo(s*.12f,s*.38f); lineTo(s*.08f,s*.50f); lineTo(s*.36f,s*.57f); lineTo(s*.30f,s*.88f)
        lineTo(s*.58f,s*.57f); close()
    }
    c.drawPath(p, brush = SolidColor(Color(0xFF657887)))
    c.drawPath(p, brush = SolidColor(Color(0xFF24343D)), style = Stroke(s*.035f))
}

private fun StarIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float, center: Offset = Offset(s/2,s/2), color: Color = Gold) {
    val path=Path()
    repeat(10) { i ->
        val a=(-90+i*36)*Math.PI/180
        val r=if(i%2==0)s*.42f else s*.19f
        val p=Offset(center.x+cos(a).toFloat()*r,center.y+sin(a).toFloat()*r)
        if(i==0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y)
    }
    path.close()
    c.drawPath(path, brush = SolidColor(color))
    c.drawPath(path, brush = SolidColor(Color(0xFFB67A16)), style = Stroke(s*.035f))
}

private fun RocketIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    c.drawOval(Rect(s*.36f,s*.12f,s*.64f,s*.82f),Color(0xFFE6E6E0))
    c.drawCircle(s*.50f,s*.30f,s*.10f,Color(0xFF69A8C8))
    c.drawPath(Path().apply{moveTo(s*.36f,s*.62f);lineTo(s*.18f,s*.82f);lineTo(s*.38f,s*.76f);close()}, brush = SolidColor(Color(0xFFDB3D2D)))
    c.drawPath(Path().apply{moveTo(s*.64f,s*.62f);lineTo(s*.82f,s*.82f);lineTo(s*.62f,s*.76f);close()}, brush = SolidColor(Color(0xFFDB3D2D)))
    c.drawCircle(s*.50f,s*.91f,s*.08f,Color(0xFFFFB13B))
}

private fun PlayIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    c.drawRoundRect(RoundRect(Rect(s*.08f,s*.18f,s*.92f,s*.82f),s*.10f),Color(0xFF1D4F76))
    c.drawCircle(s*.50f,s*.50f,s*.22f,Color.White)
    c.drawPath(Path().apply{moveTo(s*.45f,s*.38f);lineTo(s*.66f,s*.50f);lineTo(s*.45f,s*.62f);close()}, brush = SolidColor(Blue))
}

private fun CardIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    c.drawRoundRect(RoundRect(Rect(s*.18f,s*.10f,s*.76f,s*.88f),s*.08f),Color(0xFFB9C4D1))
    c.drawRoundRect(RoundRect(Rect(s*.34f,s*.04f,s*.86f,s*.76f),s*.08f),Color(0xFFE8EEF2))
    c.drawCircle(s*.60f,s*.38f,s*.10f,Color(0xFF49678C))
}

private fun ReelIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    c.drawRoundRect(RoundRect(Rect(s*.16f,s*.14f,s*.84f,s*.86f),s*.08f),Color(0xFF9A7130))
    c.drawRect(s*.27f,s*.28f,s*.73f,s*.60f,Color(0xFFFFEBC2))
    c.drawCircle(s*.36f,s*.44f,s*.06f,Red)
    c.drawCircle(s*.50f,s*.44f,s*.06f,Red)
    c.drawCircle(s*.64f,s*.44f,s*.06f,Red)
}

private fun BaseIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val p=Path().apply{moveTo(s*.12f,s*.50f);lineTo(s*.50f,s*.15f);lineTo(s*.88f,s*.50f);close()}
    c.drawPath(p, brush = SolidColor(Gold2)); c.drawRect(s*.24f,s*.48f,s*.76f,s*.84f,Color(0xFF5C6540))
    c.drawRect(s*.44f,s*.62f,s*.56f,s*.84f,Color(0xFF29331B))
}

private fun ShieldIconDraw(c: androidx.compose.ui.graphics.drawscope.DrawScope, s: Float) {
    val p=Path().apply{moveTo(s*.50f,s*.10f);lineTo(s*.82f,s*.22f);lineTo(s*.76f,s*.66f);quadraticBezierTo(s*.50f,s*.90f,s*.24f,s*.66f);lineTo(s*.18f,s*.22f);close()}
    c.drawPath(p, brush = SolidColor(Color(0xFF71833A))); c.drawPath(p, brush = SolidColor(Color(0xFFCFB04A)), style = Stroke(s*.045f))
}
