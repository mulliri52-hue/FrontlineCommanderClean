package com.frontline.commander

import android.app.Activity
import android.content.Context
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

private val Olive = Color(0xFF4E632C)
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.random.Random

private val Navy = Color(0xFF16243A)
private val Navy2 = Color(0xFF243B5A)
private val DeepGreen = Color(0xFF304C3A)
private val Cream = Color(0xFFFFF8E9)
private val Blue = Color(0xFF4D8DF7)
private val Yellow = Color(0xFFFFD24A)
private val Red = Color(0xFFE94B4B)
private val Gold = Color(0xFFFFB52E)
private val LightGreen = Color(0xFFE7F3E8)
private val Purple = Color(0xFF7A5AF8)

private const val MAX_SPINS = 100
private const val STARTING_SPINS = 17
private const val SPIN_RECHARGE_MS = 3 * 60 * 1000L
private const val REWARDED_AD_TEST_ID = "ca-app-pub-3940256099942544/5224354917"
private const val BANNER_AD_ID = "ca-app-pub-3355766770615296/8061386012"

private data class Symbol(val icon: String, val name: String)

private val slotSymbols = listOf(
    Symbol("🪖", "ELMETTO"),
    Symbol("🎖️", "MEDAGLIA"),
    Symbol("🚁", "ELICOTTERO"),
    Symbol("🛡️", "SCUDO"),
    Symbol("💥", "ESPLOSIONE"),
    Symbol("⭐", "STELLA"),
    Symbol("💎", "DIAMANTE")
)

private data class WinRule(val symbol: String, val label: String, val multiplier: Int)

private val winRules = listOf(
    WinRule("💎", "DIAMANTI", 50),
    WinRule("⭐", "STELLE", 20),
    WinRule("🚁", "ELICOTTERI", 10),
    WinRule("🎖️", "MEDAGLIE", 5),
    WinRule("🪖", "ELMETTI", 3),
    WinRule("🛡️", "SCUDI", 2)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        setContent { FrontlineApp() }
    }
}

private class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("frontline_game", Context.MODE_PRIVATE)

    var coins: Int
        get() = prefs.getInt("coins", 1250)
        set(value) = prefs.edit().putInt("coins", value.coerceAtLeast(0)).apply()

    var spins: Int
        get() = prefs.getInt("spins", STARTING_SPINS).coerceIn(0, MAX_SPINS)
        set(value) = prefs.edit().putInt("spins", value.coerceIn(0, MAX_SPINS)).apply()

    var power: Int
        get() = prefs.getInt("power", 18)
        set(value) = prefs.edit().putInt("power", value.coerceAtLeast(0)).apply()

    var maxPower: Int
        get() = prefs.getInt("maxPower", 50)
        set(value) = prefs.edit().putInt("maxPower", value.coerceAtLeast(1)).apply()

    var xp: Int
        get() = prefs.getInt("xp", 240)
        set(value) = prefs.edit().putInt("xp", value.coerceAtLeast(0)).apply()

    var hq: Int
        get() = prefs.getInt("hq", 2)
        set(value) = prefs.edit().putInt("hq", value.coerceAtLeast(1)).apply()

    var streak: Int
        get() = prefs.getInt("streak", 1)
        set(value) = prefs.edit().putInt("streak", value.coerceAtLeast(1)).apply()

    var lastSpinRecharge: Long
        get() = prefs.getLong("last_spin_recharge", System.currentTimeMillis())
        set(value) = prefs.edit().putLong("last_spin_recharge", value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", true)
        set(value) = prefs.edit().putBoolean("sound_enabled", value).apply()
}

@Composable
fun FrontlineApp() {
    val context = LocalContext.current
    val store = remember { GameStore(context) }
    val sound = remember { GameSound(context) }

    var coins by remember { mutableIntStateOf(store.coins) }
    var spins by remember { mutableIntStateOf(store.spins) }
    var power by remember { mutableIntStateOf(store.power) }
    var maxPower by remember { mutableIntStateOf(store.maxPower) }
    var xp by remember { mutableIntStateOf(store.xp) }
    var hq by remember { mutableIntStateOf(store.hq) }
    var message by remember { mutableStateOf("Pronto al lancio, Comandante!") }
    var reels by remember { mutableStateOf(listOf("🪖", "🎖️", "🚁")) }
    var spinning by remember { mutableStateOf(false) }
    var streak by remember { mutableIntStateOf(store.streak) }
    var rechargeSeconds by remember { mutableIntStateOf(0) }
    var lastMultiplier by rememberSaveable { mutableIntStateOf(0) }
    var lastWinCoins by rememberSaveable { mutableIntStateOf(0) }
    var lastResult by rememberSaveable { mutableStateOf("Nessun giro ancora") }
    var soundEnabled by remember { mutableStateOf(store.soundEnabled) }
    var rewardedAd by remember { mutableStateOf<RewardedAd?>(null) }
    var adLoading by remember { mutableStateOf(false) }
    var showRewardInfo by remember { mutableStateOf(false) }

    fun persist() {
        store.coins = coins
        store.spins = spins
        store.power = power
        store.maxPower = maxPower
        store.xp = xp
        store.hq = hq
        store.streak = streak
        store.soundEnabled = soundEnabled
    }

    fun loadRewardedAd() {
        if (adLoading || rewardedAd != null) return
        adLoading = true
        RewardedAd.load(
            context,
            REWARDED_AD_TEST_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    adLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    adLoading = false
                }
            }
        )
    }

    DisposableEffect(Unit) {
        loadRewardedAd()
        onDispose { sound.release() }
    }

    LaunchedEffect(soundEnabled) {
        sound.setEnabled(soundEnabled)
    }

    LaunchedEffect(Unit) {
        while (true) {
            val now = System.currentTimeMillis()
            if (spins >= MAX_SPINS) {
                rechargeSeconds = 0
            } else {
                val elapsed = max(0L, now - store.lastSpinRecharge)
                val gained = (elapsed / SPIN_RECHARGE_MS).toInt()
                if (gained > 0) {
                    val actual = minOf(gained, MAX_SPINS - spins)
                    spins += actual
                    store.lastSpinRecharge += actual * SPIN_RECHARGE_MS
                    persist()
                }
                val remaining = SPIN_RECHARGE_MS - max(0L, System.currentTimeMillis() - store.lastSpinRecharge)
                rechargeSeconds = max(0L, remaining / 1000L).toInt()
            }
            delay(1000)
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Cream)) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(true, {}, icon = { Text("🏠") }, label = { Text("Base") })
                    NavigationBarItem(false, {}, icon = { Text("🎰") }, label = { Text("Ruota") })
                    NavigationBarItem(false, {}, icon = { Text("💥") }, label = { Text("Raid") })
                    NavigationBarItem(false, {}, icon = { Text("🪖") }, label = { Text("Squadra") })
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFFFFFBF1), Cream, Color(0xFFEAF1F8)))
                    )
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Header(coins, power, spins, soundEnabled) {
                    soundEnabled = !soundEnabled
                    persist()
                    if (soundEnabled) sound.tap()
                }

                Spacer(Modifier.height(10.dp))
                EventBanner()
                Spacer(Modifier.height(14.dp))
                BaseCard(power, maxPower)
                Spacer(Modifier.height(18.dp))

                Text("CENTRO OPERAZIONI", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("Ruota tattica", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                WinBoard()
                Spacer(Modifier.height(8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Navy)
                ) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("🎰 SLOT TATTICA", color = Color.White, fontWeight = FontWeight.ExtraBold)
                            Text("STREAK ×$streak", color = Yellow, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(10.dp))

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            reels.forEachIndexed { index, reel ->
                                Card(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(17.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    AnimatedContent(
                                        targetState = reel,
                                        transitionSpec = { (fadeIn() + scaleIn()) togetherWith fadeOut() },
                                        label = "reel_$index"
                                    ) { icon ->
                                        Text(
                                            icon,
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 25.dp),
                                            fontSize = 43.sp,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }

                        if (lastMultiplier > 0) {
                            Spacer(Modifier.height(7.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (lastMultiplier >= 10) Color(0xFFFFD54F) else Color(0xFFE8F5E9)
                                )
                            ) {
                                Column(
                                    Modifier.padding(9.dp).fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        "✦ MOLTIPLICATORE ×$lastMultiplier ✦",
                                        color = Navy,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        "+$lastWinCoins 🪙  •  $lastResult",
                                        color = Navy,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        Text(message, color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))

                        Button(
                            onClick = {
                                if (!spinning && spins > 0) {
                                    spinning = true
                                    val wasFull = spins == MAX_SPINS
                                    spins--
                                    if (wasFull) store.lastSpinRecharge = System.currentTimeMillis()
                                    power = (power - 1).coerceAtLeast(0)
                                    lastMultiplier = 0
                                    persist()
                                    message = "I RULLI GIRANO..."
                                    if (soundEnabled) sound.spin()
                                }
                            },
                            enabled = !spinning && spins > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Navy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (spinning) "🔄 RULLI IN MOVIMENTO..." else "⚡ GIRA • 1 GIRO", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        }

                        if (!spinning && spins < MAX_SPINS) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (rechargeSeconds > 0) {
                                    "⏱️ +1 giro tra ${rechargeSeconds / 60}:${(rechargeSeconds % 60).toString().padStart(2, '0')}  •  $spins/$MAX_SPINS"
                                } else {
                                    "🎉 Giro pronto!"
                                },
                                color = Yellow,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                LaunchedEffect(spinning) {
                    if (spinning) {
                        val symbols = slotSymbols.map { it.icon }
                        repeat(16) { reels = List(3) { symbols.random() }; delay(75) }
                        repeat(8) { reels = List(3) { symbols.random() }; delay(115) }

                        val first = symbols.random()
                        repeat(5) { reels = listOf(first, symbols.random(), symbols.random()); delay(135) }
                        val second = symbols.random()
                        repeat(4) { reels = listOf(first, second, symbols.random()); delay(175) }
                        val third = symbols.random()
                        reels = listOf(first, second, third)

                        val same = first == second && second == third
                        val pair = first == second || second == third || first == third
                        when {
                            same -> {
                                val multiplier = winRules.firstOrNull { it.symbol == first }?.multiplier ?: 2
                                val gain = 100 * multiplier + streak * 25
                                lastMultiplier = multiplier
                                lastWinCoins = gain
                                lastResult = "$first $second $third"
                                coins += gain
                                xp += 25 * multiplier
                                power = (power + 2).coerceAtMost(maxPower)
                                streak++
                                message = "🏆 VITTORIA ×$multiplier! +$gain 🪙"
                                if (soundEnabled) sound.win()
                            }
                            pair -> {
                                lastMultiplier = 2
                                lastWinCoins = 120
                                lastResult = "$first $second $third"
                                coins += 120
                                xp += 15
                                streak++
                                message = "🎯 DOPPIA ×2! +120 🪙"
                                if (soundEnabled) sound.win()
                            }
                            else -> {
                                lastMultiplier = 0
                                lastWinCoins = 40
                                lastResult = "$first $second $third"
                                coins += 40
                                xp += 5
                                streak = 1
                                message = "Rifornimento +40 🪙"
                                if (soundEnabled) sound.lose()
                            }
                        }
                        persist()
                        spinning = false
                    }
                }

                Spacer(Modifier.height(12.dp))
                RewardCard(
                    spins = spins,
                    adLoading = adLoading,
                    onWatch = {
                        val ad = rewardedAd
                        val activity = context as? Activity
                        if (ad != null && activity != null) {
                            ad.show(activity) { _: RewardItem ->
                                spins = (spins + 10).coerceAtMost(MAX_SPINS)
                                message = "🎁 +10 GIRI BONUS!"
                                persist()
                                if (soundEnabled) sound.win()
                            }
                            rewardedAd = null
                            loadRewardedAd()
                        } else {
                            showRewardInfo = true
                            loadRewardedAd()
                        }
                    }
                )

                if (showRewardInfo) {
                    Card(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF2CC))
                    ) {
                        Text(
                            "La pubblicità bonus non è ancora pronta. Riprova tra poco.",
                            modifier = Modifier.padding(12.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Navy
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    Column {
                        Text("IL TUO AVAMPOSTO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("Costruisci e potenzia", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Button(
                        onClick = {
                            val cost = 500 + 350 * hq
                            if (coins >= cost) {
                                coins -= cost
                                hq++
                                maxPower += 5
                                xp += 40
                                message = "Base potenziata! ★"
                                persist()
                            } else message = "Servono più 🪙"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)
                    ) { Text("⬆ POTENZIA") }
                }

                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Building("🏠", "Comando", "Lv.$hq", Modifier.weight(1f))
                    Building("🛠️", "Officina", "+ produzione", Modifier.weight(1f))
                    Building("📡", "Radar", "+ raid", Modifier.weight(1f))
                }

                Spacer(Modifier.height(18.dp))
                Text("ATTACCO & RAID", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("Operazioni lampo", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))

                val raidList = listOf(
                    "🌲 🪖 🌲" to "Sentiero Verde",
                    "☀️ 🏜️ 🛡️" to "Deposito Rosso",
                    "🌊 🛩️ 🌊" to "Onda Blu"
                )
                raidList.forEachIndexed { index, raid ->
                    val cost = index + 3
                    val reward = listOf(240, 380, 300)[index]
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable {
                            if (power >= cost) {
                                power -= cost
                                coins += reward
                                xp += 40
                                message = "Operazione riuscita!"
                                persist()
                                if (soundEnabled) sound.win()
                            } else message = "Potere insufficiente ⚡"
                        },
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(raid.first, fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(raid.second, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                                Text("⚡ $cost • ricompensa 🪙 $reward", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))
                Text("PROGRESSIONE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("Squadra Alpha", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Unit("🪖", "Ranger", "Lv.3", Modifier.weight(1f))
                    Unit("🧨", "Blaster", "Lv.2", Modifier.weight(1f))
                    Unit("🛡️", "Guard", "Lv.3", Modifier.weight(1f))
                }

                Spacer(Modifier.height(22.dp))
                Text(
                    "🎯 EVENTO • Operazione Fulmine • Ricompense speciali in arrivo",
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(LightGreen).padding(14.dp),
                    fontWeight = FontWeight.Bold,
                    color = DeepGreen
                )
                Spacer(Modifier.height(20.dp))
                BannerAd()
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun Header(coins: Int, power: Int, spins: Int, soundEnabled: Boolean, onSoundToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("★", fontSize = 30.sp, color = Gold)
            Spacer(Modifier.width(7.dp))
            Column {
                Text("FRONTLINE", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("COMMANDER", fontSize = 9.sp, color = Color.Gray)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Resource("🎟️", spins.toString())
            Spacer(Modifier.width(5.dp))
            Resource("🪙", coins.toString())
            Spacer(Modifier.width(5.dp))
            Resource("⚡", power.toString())
            Spacer(Modifier.width(5.dp))
            Text(if (soundEnabled) "🔊" else "🔇", Modifier.clickable { onSoundToggle() }.padding(4.dp), fontSize = 20.sp)
        }
    }
}

@Composable
private fun EventBanner() {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = DeepGreen)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🎯", fontSize = 34.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("OPERAZIONE FULMINE", color = Color.White, fontWeight = FontWeight.ExtraBold)
                Text("Evento speciale • nuove ricompense in arrivo", color = Color(0xFFE7F3E8), fontSize = 11.sp)
            }
            Text("EVENTO", color = Yellow, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
        }
    }
}

@Composable
private fun BaseCard(power: Int, maxPower: Int) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F7FF))) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SETTORE 07", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("La tua base.", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Text("Gira, accumula e conquista.", color = Color(0xFF65758C))
                Spacer(Modifier.height(10.dp))
                Text("⚡ POTERE OPERATIVO  $power/$maxPower", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                LinearProgressIndicator(
                    progress = { power.toFloat() / maxPower.toFloat() },
                    modifier = Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(8.dp)),
                    color = Yellow,
                    trackColor = Color.White
                )
            }
            Text("🏢\n📡\n🛡️", fontSize = 40.sp, lineHeight = 49.sp)
        }
    }
}

@Composable
private fun WinBoard() {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp).animateContentSize()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Olive)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🪖", fontSize = 30.sp)
                                Text("🏕️  BASE AVANZATA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                Text("🚁", fontSize = 30.sp)
                            }
                        }

                        Spacer(Modifier.height(10.dp))

                Text("🏆 COMBINAZIONI VINCENTI", fontWeight = FontWeight.ExtraBold)
                Text("PREMI", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(7.dp))
            winRules.forEach { rule ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${rule.symbol} ${rule.symbol} ${rule.symbol}", modifier = Modifier.weight(1f), fontSize = 18.sp)
                    Text(rule.label, modifier = Modifier.weight(1f), fontSize = 10.sp, color = Color.Gray)
                    Text("×${rule.multiplier}", fontWeight = FontWeight.ExtraBold, color = if (rule.multiplier >= 10) Red else Navy)
                }
            }
        }
    }
}

@Composable
private fun RewardCard(spins: Int, adLoading: Boolean, onWatch: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("🎁 GIRI BONUS", fontWeight = FontWeight.ExtraBold, color = Purple)
                Text("Guarda un video e ricevi +10 giri", fontSize = 11.sp, color = Color.Gray)
                Text("Disponibili: $spins/$MAX_SPINS", fontSize = 10.sp, color = Color.Gray)
            }
            Button(
                onClick = onWatch,
                enabled = !adLoading,
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) { Text(if (adLoading) "CARICO..." else "▶ +10") }
        }
    }
}

@Composable
private fun Resource(icon: String, value: String) {
    Text("$icon $value", Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White).padding(8.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
}

@Composable
private fun Building(icon: String, name: String, sub: String, modifier: Modifier) {
    Card(modifier, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
        Column(Modifier.padding(12.dp)) {
            Text(icon, fontSize = 30.sp)
            Text(name, fontWeight = FontWeight.Bold)
            Text(sub, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun Unit(icon: String, name: String, level: String, modifier: Modifier) {
    Card(modifier, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 30.sp)
            Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(level, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun BannerAd() {
    AndroidView<AdView>(
        factory = { ctx: Context ->
            AdView(ctx).apply {
                adUnitId = BANNER_AD_ID
                setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(ctx, 360))
                loadAd(AdRequest.Builder().build())
            }
        },
        modifier = Modifier.fillMaxWidth()
    )
}

private class GameSound(context: Context) {
    private val pool: SoundPool
    private val music: MediaPlayer
    private val spinId: Int
    private val winId: Int
    private val loseId: Int
    private val tapId: Int
    private var enabled = true

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(4).build()
        spinId = pool.load(context, R.raw.slot_spin, 1)
        winId = pool.load(context, R.raw.slot_win, 1)
        loseId = pool.load(context, R.raw.slot_lose, 1)
        tapId = pool.load(context, R.raw.slot_tap, 1)
        music = MediaPlayer.create(context, R.raw.frontline_music).apply {
            isLooping = true
            setVolume(0.18f, 0.18f)
        }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        if (enabled) {
            if (!music.isPlaying) music.start()
        } else if (music.isPlaying) {
            music.pause()
        }
    }

    fun spin() { if (enabled) pool.play(spinId, 0.55f, 0.55f, 1, 0, 1f) }
    fun win() { if (enabled) pool.play(winId, 0.75f, 0.75f, 1, 0, 1.05f) }
    fun lose() { if (enabled) pool.play(loseId, 0.4f, 0.4f, 1, 0, 0.9f) }
    fun tap() { if (enabled) pool.play(tapId, 0.25f, 0.25f, 1, 0, 1.2f) }

    fun release() {
        if (music.isPlaying) music.stop()
        music.release()
        pool.release()
    }
}
