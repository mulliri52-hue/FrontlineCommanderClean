package com.frontline.commander

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Navy = Color(0xFF24324A)
private val Cream = Color(0xFFFFFAF0)
private val Blue = Color(0xFF4D8DF7)
private val Yellow = Color(0xFFFFD24A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        MobileAds.initialize(this)

        setContent {
            FrontlineApp()
        }
    }
}

@Composable
fun FrontlineApp() {
    var coins by remember { mutableIntStateOf(1250) }
    var power by remember { mutableIntStateOf(18) }
    var maxPower by remember { mutableIntStateOf(50) }
    var xp by remember { mutableIntStateOf(240) }
    var hq by remember { mutableIntStateOf(2) }
    var message by remember { mutableStateOf("Pronto al lancio, Comandante!") }
    var reels by remember { mutableStateOf(listOf("🪖", "🪙", "🛡️")) }
    var spinning by remember { mutableStateOf(false) }
    var streak by remember { mutableIntStateOf(1) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(300_000)
            if (power < maxPower) {
                power++
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            background = Cream
        )
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = true,
                        onClick = {},
                        icon = { Text("🏠") },
                        label = { Text("Base") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = {},
                        icon = { Text("🎰") },
                        label = { Text("Ruota") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = {},
                        icon = { Text("💥") },
                        label = { Text("Raid") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = {},
                        icon = { Text("🪖") },
                        label = { Text("Squadra") }
                    )
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .background(Cream)
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("★", fontSize = 28.sp)
                        Spacer(Modifier.width(7.dp))
                        Column {
                            Text(
                                "FRONTLINE",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp
                            )
                            Text(
                                "COMMANDER",
                                fontSize = 9.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Row {
                        Resource("🪙", coins.toString())
                        Spacer(Modifier.width(5.dp))
                        Resource("⚡", power.toString())
                    }
                }

                Spacer(Modifier.height(14.dp))

                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFE8F7FF)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "SETTORE 07",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text(
                                "La tua base.",
                                fontSize = 30.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                "Gira, accumula e conquista.",
                                color = Color(0xFF65758C)
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "⚡ POTERE OPERATIVO  $power/$maxPower",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            LinearProgressIndicator(
                                progress = { power.toFloat() / maxPower.toFloat() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(9.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                color = Yellow,
                                trackColor = Color.White
                            )
                        }

                        Text(
                            "🏢\n📡\n🛡️",
                            fontSize = 42.sp,
                            lineHeight = 52.sp
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))

                Text(
                    "CENTRO OPERAZIONI",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    "Ruota tattica",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(Modifier.height(8.dp))

                Card(
                    shape = RoundedCornerShape(25.dp),
                    colors = CardDefaults.cardColors(containerColor = Navy)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "RUOTA TATTICA",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                "STREAK ×$streak",
                                color = Yellow,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            reels.forEach { reel ->
                                Text(
                                    text = reel,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(17.dp))
                                        .background(Color.White)
                                        .padding(vertical = 23.dp),
                                    fontSize = 42.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        Text(
                            message,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(8.dp)
                        )

                        Button(
                            onClick = {
                                if (!spinning && power > 0) {
                                    spinning = true
                                    power--
                                    reels = listOf("💥", "⚙️", "🎯")
                                    message = "..."
                                }
                            },
                            enabled = !spinning && power > 0,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Yellow,
                                contentColor = Navy
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "⚡ GIRA • 1 POTERE",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }

                LaunchedEffect(spinning) {
                    if (spinning) {
                        delay(650)

                        val symbols = listOf(
                            "🪖", "🪙", "🛡️", "💥", "⚙️", "🎯", "⭐"
                        )

                        reels = List(3) { symbols.random() }

                        val distinctCount = reels.distinct().size

                        when (distinctCount) {
                            1 -> {
                                val gain = 600 + streak * 100
                                coins += gain
                                xp += 80
                                power = (power + 3).coerceAtMost(maxPower)
                                streak++
                                message = "JACKPOT! +$gain 🪙 • +3 ⚡"
                            }

                            2 -> {
                                coins += 180
                                xp += 30
                                streak++
                                message = "COMBINAZIONE! +180 🪙"
                            }

                            else -> {
                                coins += 60
                                xp += 10
                                streak = 1
                                message = "Rifornimento! +60 🪙"
                            }
                        }

                        spinning = false
                    }
                }

                Spacer(Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            "IL TUO AVAMPOSTO",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray
                        )
                        Text(
                            "Costruisci e potenzia",
                            fontSize = 25.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Button(
                        onClick = {
                            val cost = 500 + 350 * hq
                            if (coins >= cost) {
                                coins -= cost
                                hq++
                                maxPower += 5
                                xp += 40
                                message = "Base potenziata! ★"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Navy
                        )
                    ) {
                        Text("⬆ POTENZIA")
                    }
                }

                Spacer(Modifier.height(9.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Building(
                        "🏠",
                        "Comando",
                        "Lv.$hq",
                        Modifier.weight(1f)
                    )
                    Building(
                        "🛠️",
                        "Officina",
                        "+ produzione",
                        Modifier.weight(1f)
                    )
                    Building(
                        "📡",
                        "Radar",
                        "+ raid",
                        Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(18.dp))

                Text(
                    "ATTACCO & RAID",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    "Operazioni lampo",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(Modifier.height(8.dp))

                val raidList = listOf(
                    "🌲 🪖 🌲" to "Sentiero Verde",
                    "☀️ 🏜️ 🛡️" to "Deposito Rosso",
                    "🌊 🛩️ 🌊" to "Onda Blu"
                )

                raidList.forEachIndexed { index, raid ->
                    val cost = index + 3
                    val reward = listOf(240, 380, 300)[index]

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .clickable {
                                if (power >= cost) {
                                    power -= cost
                                    coins += reward
                                    xp += 40
                                    message = "Operazione riuscita!"
                                } else {
                                    message = "Potere insufficiente ⚡"
                                }
                            },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(raid.first, fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))

                            Column {
                                Text(
                                    raid.second,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    "⚡ $cost • ricompensa",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                Text(
                    "PROGRESSIONE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    "Squadra Alpha",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Unit("🪖", "Ranger", "Lv.3", Modifier.weight(1f))
                    Unit("🧨", "Blaster", "Lv.2", Modifier.weight(1f))
                    Unit("🛡️", "Guard", "Lv.3", Modifier.weight(1f))
                }

                Spacer(Modifier.height(30.dp))

                BannerAd()

                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun Resource(icon: String, value: String) {
    Text(
        text = "$icon $value",
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .padding(8.dp),
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp
    )
}

@Composable
fun Building(
    icon: String,
    name: String,
    sub: String,
    modifier: Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(icon, fontSize = 30.sp)
            Text(name, fontWeight = FontWeight.Bold)
            Text(sub, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun Unit(
    icon: String,
    name: String,
    level: String,
    modifier: Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 30.sp)
            Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(level, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun BannerAd() {
    val context = LocalContext.current

    AndroidView(
        modifier = Modifier.fillMaxWidth(),
        factory = {
            AdView(context).apply {
                adUnitId = "ca-app-pub-3355766770615296/8061386012"
                setAdSize(
                    AdSize.getLargeAnchoredAdaptiveBannerAdSize(
                        context,
                        360
                    )
                )
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
