package com.frontline.commander

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.random.Random

private val Navy = Color(0xFF24324A)
private val DeepGreen = Color(0xFF304C3A)
private val Cream = Color(0xFFFFF8E9)
private val Blue = Color(0xFF4D8DF7)
private val Yellow = Color(0xFFFFD24A)
private val Red = Color(0xFFE94B4B)
private val Gold = Color(0xFFFFB52E)
private val LightGreen = Color(0xFFE7F3E8)

private const val MAX_SPINS = 50
private const val SPIN_RECHARGE_MS = 3 * 60 * 1000L

private data class Symbol(val icon: String, val name: String)

private val slotSymbols = listOf(
    Symbol("🪖", "ELMETTO"),
    Symbol("🎖️", "MEDAGLIA"),
    Symbol("🚁", "ELICOTTERO"),
    Symbol("🛡️", "SCUDO"),
    Symbol("💥", "ESPLOSIONE"),
    Symbol("⭐", "STELLA"),
    Symbol("💎", "DIAMANTE")
)

private data class WinRule(
    val icons: String,
    val label: String,
    val multiplier: Int
)

private val winRules = listOf(
    WinRule("💎 💎 💎", "DIAMANTI", 50),
    WinRule("⭐ ⭐ ⭐", "STELLE", 20),
    WinRule("🚁 🚁 🚁", "ELICOTTERI", 10),
    WinRule("🎖️ 🎖️ 🎖️", "MEDAGLIE", 5),
    WinRule("🪖 🪖 🪖", "ELMETTI", 3),
    WinRule("🛡️ 🛡️ 🛡️", "SCUDI", 2)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        setContent { FrontlineApp() }
    }
}

private class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("frontline_game", Context.MODE_PRIVATE)

    var coins: Int
        get() = prefs.getInt("coins", 1250)
        set(value) = prefs.edit().putInt("coins", value).apply()

    var spins: Int
        get() = prefs.getInt("spins", 17)
        set(value) = prefs.edit().putInt("spins", value.coerceIn(0, MAX_SPINS)).apply()

    var power: Int
        get() = prefs.getInt("power", 18)
        set(value) = prefs.edit().putInt("power", value.coerceAtLeast(0)).apply()

    var maxPower: Int
        get() = prefs.getInt("maxPower", 50)
        set(value) = prefs.edit().putInt("maxPower", value).apply()

    var xp: Int
        get() = prefs.getInt("xp", 240)
        set(value) = prefs.edit().putInt("xp", value).apply()

    var hq: Int
        get() = prefs.getInt("hq", 2)
        set(value) = prefs.edit().putInt("hq", value).apply()

    var streak: Int
        get() = prefs.getInt("streak", 1)
        set(value) = prefs.edit().putInt("streak", value).apply()

    var lastSpinRecharge: Long
        get() = prefs.getLong("last_spin_recharge", System.currentTimeMillis())
        set(value) = prefs.edit().putLong("last_spin_recharge", value).apply()
}

@Composable
fun FrontlineApp() {
    val context = LocalContext.current
    val store = remember { GameStore(context) }

    var coins by remember { mutableIntStateOf(store.coins) }
    var spins by remember { mutableIntStateOf(store.spins) }
    var power by remember { mutableIntStateOf(store.power) }
    var maxPower by remember { mutableIntStateOf(store.maxPower) }
    var xp by remember { mutableIntStateOf(store.xp) }
    var hq by remember { mutableIntStateOf(store.hq) }
    var message by remember { mutableStateOf("Pronto al lancio, Comandante!") }
    var reels by remember { mutableStateOf(listOf("🪖", "🎖️", "🚁")) }
    var spinning by remember { mutableStateOf(false) }
    var streak by remember { mutableIntStateOf(store.streak) }
    var rechargeSeconds by remember { mutableIntStateOf(0) }

    fun persist() {
        store.coins = coins
        store.spins = spins
        store.power = power
        store.maxPower = maxPower
        store.xp = xp
        store.hq = hq
        store.streak = streak
    }

    // Offline spin regeneration: 1 spin every 3 minutes, capped at 50.
    LaunchedEffect(Unit) {
        while (true) {
            val now = System.currentTimeMillis()

            if (spins >= MAX_SPINS) {
                // At the cap there is no pending recharge. Start a fresh 3-minute
                // timer only when a spin is spent from the full stock.
                store.lastSpinRecharge = now
                rechargeSeconds = 0
            } else {
                val elapsed = max(0L, now - store.lastSpinRecharge)
                val gained = (elapsed / SPIN_RECHARGE_MS).toInt()

                if (gained > 0) {
                    val actual = minOf(gained, MAX_SPINS - spins)
                    spins += actual
                    store.lastSpinRecharge = store.lastSpinRecharge + actual * SPIN_RECHARGE_MS
                    persist()

                    // If the cap was reached, discard any leftover accumulated time
                    // so the next recharge begins after the next spin is spent.
                    if (spins >= MAX_SPINS) {
                        store.lastSpinRecharge = now
                    }
                }

                val remaining = SPIN_RECHARGE_MS - (System.currentTimeMillis() - store.lastSpinRecharge)
                rechargeSeconds = max(0L, remaining / 1000L).toInt()
            }
            delay(1000)
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            background = Cream
        )
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(true, {}, icon = { Text("🏠") }, label = { Text("Base") })
                    NavigationBarItem(false, {}, icon = { Text("🎰") }, label = { Text("Ruota") })
                    NavigationBarItem(false, {}, icon = { Text("💥") }, label = { Text("Raid") })
                    NavigationBarItem(false, {}, icon = { Text("🪖") }, label = { Text("Squadra") })
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .background(Cream)
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Header(coins, power, spins)

                Spacer(Modifier.height(10.dp))

                EventBanner()

                Spacer(Modifier.height(14.dp))

                BaseCard(power, maxPower)

                Spacer(Modifier.height(18.dp))

                Text("CENTRO OPERAZIONI", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("Ruota tattica", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)

                Spacer(Modifier.height(8.dp))

                WinBoard()

                Spacer(Modifier.height(8.dp))

                Card(
                    shape = RoundedCornerShape(25.dp),
                    colors = CardDefaults.cardColors(containerColor = Navy)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("🎰 SLOT TATTICA", color = Color.White, fontWeight = FontWeight.ExtraBold)
                            Text("STREAK ×$streak", color = Yellow, fontWeight = FontWeight.Bold)
                        }

                        Spacer(Modifier.height(10.dp))

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            reels.forEach { reel ->
                                Card(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(17.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Text(
                                        reel,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 25.dp),
                                        fontSize = 43.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        Text(
                            message,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(Modifier.height(8.dp))

                        Button(
                            onClick = {
                                if (!spinning && spins > 0) {
                                    spinning = true
                                    val wasFull = spins >= MAX_SPINS
                                    spins--
                                    store.spins = spins
                                    if (wasFull) {
                                        // Starting from the full cap: the next spin is
                                        // earned exactly 3 minutes after this spend.
                                        store.lastSpinRecharge = System.currentTimeMillis()
                                    }
                                    power = (power - 1).coerceAtLeast(0)
                                    persist()
                                    message = "I RULLI GIRANO..."
                                }
                            },
                            enabled = !spinning && spins > 0,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Yellow,
                                contentColor = Navy
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (spinning) "🔄 RULLI IN MOVIMENTO..." else "⚡ GIRA • 1 GIRO",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                        }

                        if (spins == 0 && !spinning) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (rechargeSeconds > 0)
                                    "⏱️ Prossimo giro tra ${rechargeSeconds / 60}:${(rechargeSeconds % 60).toString().padStart(2, '0')}"
                                else
                                    "🎉 Giri pronti!",
                                color = Yellow,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Real sequential reel animation.
                LaunchedEffect(spinning) {
                    if (spinning) {
                        val symbols = slotSymbols.map { it.icon }

                        repeat(10) {
                            reels = List(3) { symbols.random() }
                            delay(70)
                        }

                        repeat(7) {
                            reels = List(3) { symbols.random() }
                            delay(100)
                        }

                        val first = symbols.random()
                        repeat(5) {
                            reels = listOf(first, symbols.random(), symbols.random())
                            delay(130)
                        }

                        val second = symbols.random()
                        repeat(4) {
                            reels = listOf(first, second, symbols.random())
                            delay(170)
                        }

                        val third = symbols.random()
                        reels = listOf(first, second, third)

                        val same = first == second && second == third
                        val pair = first == second || second == third || first == third

                        when {
                            same -> {
                                val multiplier = winRules.firstOrNull { it.icons.startsWith("$first $first") }?.multiplier
                                    ?: 2
                                val gain = 100 * multiplier + streak * 25
                                coins += gain
                                xp += 25 * multiplier
                                power = (power + 2).coerceAtMost(maxPower)
                                streak++
                                message = "🏆 VITTORIA ×$multiplier! +$gain 🪙"
                            }
                            pair -> {
                                coins += 120
                                xp += 15
                                streak++
                                message = "🎯 DOPPIA! +120 🪙"
                            }
                            else -> {
                                coins += 40
                                xp += 5
                                streak = 1
                                message = "Rifornimento +40 🪙"
                            }
                        }

                        persist()
                        spinning = false
                    }
                }

                Spacer(Modifier.height(18.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text("IL TUO AVAMPOSTO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("Costruisci e potenzia", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    }

                    Button(
                        onClick = {
                            val cost = 500 + 350 * hq
                            if (coins >= cost) {
                                coins -= cost
                                hq++
                                maxPower += 5
                                xp += 40
                                message = "Base potenziata! ★"
                                persist()
                            } else {
                                message = "Servono più 🪙"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)
                    ) { Text("⬆ POTENZIA") }
                }

                Spacer(Modifier.height(9.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Building("🏠", "Comando", "Lv.$hq", Modifier.weight(1f))
                    Building("🛠️", "Officina", "+ produzione", Modifier.weight(1f))
                    Building("📡", "Radar", "+ raid", Modifier.weight(1f))
                }

                Spacer(Modifier.height(18.dp))

                Text("ATTACCO & RAID", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("Operazioni lampo", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)

                Spacer(Modifier.height(8.dp))

                val raidList = listOf(
                    "🌲 🪖 🌲" to "Sentiero Verde",
                    "☀️ 🏜️ 🛡️" to "Deposito Rosso",
                    "🌊 🛩️ 🌊" to "Onda Blu"
                )

                raidList.forEachIndexed { index, raid ->
                    val cost = index + 3
                    val reward = listOf(240, 380, 300)[index]

                    Card(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .clickable {
                                if (power >= cost) {
                                    power -= cost
                                    coins += reward
                                    xp += 40
                                    message = "Operazione riuscita!"
                                    persist()
                                } else message = "Potere insufficiente ⚡"
                            },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(raid.first, fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(raid.second, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                                Text("⚡ $cost • ricompensa 🪙 $reward", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))

                Text("PROGRESSIONE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("Squadra Alpha", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)

                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Unit("🪖", "Ranger", "Lv.3", Modifier.weight(1f))
                    Unit("🧨", "Blaster", "Lv.2", Modifier.weight(1f))
                    Unit("🛡️", "Guard", "Lv.3", Modifier.weight(1f))
                }

                Spacer(Modifier.height(22.dp))

                Text(
                    "🎁 BONUS EVENTO • Presto: +10 giri guardando un video",
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(LightGreen)
                        .padding(14.dp),
                    fontWeight = FontWeight.Bold,
                    color = DeepGreen
                )

                Spacer(Modifier.height(20.dp))
                BannerAd()
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun Header(coins: Int, power: Int, spins: Int) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("★", fontSize = 30.sp, color = Gold)
            Spacer(Modifier.width(7.dp))
            Column {
                Text("FRONTLINE", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("COMMANDER", fontSize = 9.sp, color = Color.Gray)
            }
        }
        Row {
            Resource("🎟️", spins.toString())
            Spacer(Modifier.width(5.dp))
            Resource("🪙", coins.toString())
            Spacer(Modifier.width(5.dp))
            Resource("⚡", power.toString())
        }
    }
}

@Composable
private fun EventBanner() {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF3B5D45))
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🎯", fontSize = 34.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("OPERAZIONE FULMINE", color = Color.White, fontWeight = FontWeight.ExtraBold)
                Text("Evento speciale • nuove ricompense in arrivo", color = Color(0xFFE7F3E8), fontSize = 11.sp)
            }
            Text("EVENTO", color = Yellow, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
        }
    }
}

@Composable
private fun BaseCard(power: Int, maxPower: Int) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F7FF))
    ) {
        Row(
            Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("SETTORE 07", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Text("La tua base.", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Text("Gira, accumula e conquista.", color = Color(0xFF65758C))
                Spacer(Modifier.height(10.dp))
                Text("⚡ POTERE OPERATIVO  $power/$maxPower", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                LinearProgressIndicator(
                    progress = { power.toFloat() / maxPower.toFloat() },
                    Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(8.dp)),
                    color = Yellow,
                    trackColor = Color.White
                )
            }
            Text("🏢\n📡\n🛡️", fontSize = 40.sp, lineHeight = 49.sp)
        }
    }
}

@Composable
private fun WinBoard() {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("🏆 COMBINAZIONI VINCENTI", fontWeight = FontWeight.ExtraBold)
                Text("PREMI", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(7.dp))
            winRules.take(4).forEach { rule ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(rule.icons, modifier = Modifier.weight(1f), fontSize = 18.sp)
                    Text(rule.label, modifier = Modifier.weight(1f), fontSize = 10.sp, color = Color.Gray)
                    Text("×${rule.multiplier}", fontWeight = FontWeight.ExtraBold, color = if (rule.multiplier >= 10) Red else Navy)
                }
            }
        }
    }
}

@Composable
fun Resource(icon: String, value: String) {
    Text(
        "$icon $value",
        Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White).padding(8.dp),
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp
    )
}

@Composable
fun Building(icon: String, name: String, sub: String, modifier: Modifier) {
    Card(modifier, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
        Column(Modifier.padding(12.dp)) {
            Text(icon, fontSize = 30.sp)
            Text(name, fontWeight = FontWeight.Bold)
            Text(sub, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun Unit(icon: String, name: String, level: String, modifier: Modifier) {
    Card(modifier, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
        Column(
            Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 30.sp)
            Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(level, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun BannerAd() {
    AndroidView<AdView>(
        factory = { ctx: Context ->
            AdView(ctx).apply {
                adUnitId = "ca-app-pub-3355766770615296/8061386012"
                setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(ctx, 360))
                loadAd(AdRequest.Builder().build())
            }
        },
        modifier = Modifier.fillMaxWidth()
    )
}
