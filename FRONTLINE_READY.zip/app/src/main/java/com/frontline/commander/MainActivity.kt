package com.frontline.commander

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random
import java.util.Locale

private val BgTop = Color(0xFF86B879)
private val BgBottom = Color(0xFF1B2A14)
private val OliveDark = Color(0xFF1E2D12)
private val Olive = Color(0xFF56653B)
private val Frame = Color(0xFF25291C)
private val Cream = Color(0xFFFFF8DF)
private val Gold = Color(0xFFFFC62E)
private val Red = Color(0xFFE84732)
private val Blue = Color(0xFF258FC8)
private val Purple = Color(0xFF7544AA)

private val symbols = listOf("🪖", "🏅", "📦", "💣", "🚁", "🚜", "✈️", "⭐")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrontlineCommanderApp() }
    }
}

@Composable
private fun FrontlineCommanderApp() {
    var coins by remember { mutableLongStateOf(8_450_000L) }
    var gems by remember { mutableIntStateOf(1_250) }
    var spins by remember { mutableIntStateOf(17) }
    var bet by remember { mutableLongStateOf(100_000L) }
    var multiplier by remember { mutableIntStateOf(1) }
    var spinning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("PRONTO AL LANCIO, COMANDANTE!") }
    var reels by remember { mutableStateOf(listOf("🪖", "🏅", "🚁")) }

    MaterialTheme(colorScheme = darkColorScheme(background = OliveDark, surface = OliveDark, primary = Gold)) {
        Scaffold(containerColor = OliveDark, bottomBar = { BottomNav() }) { padding ->
            Box(
                Modifier.fillMaxSize().padding(padding).background(
                    Brush.verticalGradient(listOf(BgTop, Color(0xFF47713A), BgBottom))
                )
            ) {
                Column(Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 6.dp)) {
                    Header(coins, gems)
                    Spacer(Modifier.height(7.dp))
                    PayTable()
                    Spacer(Modifier.height(7.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        SideColumn(
                            Modifier.weight(0.21f),
                            listOf("🎁" to "MISSIONI\n2", "🏆" to "CLASSIFICA\n2g 14h", "🎁" to "RICOMPENSE\n14h")
                        )
                        SlotMachine(
                            Modifier.weight(0.58f),
                            reels = reels,
                            spinning = spinning,
                            result = result,
                            bet = bet,
                            multiplier = multiplier,
                            onBetMinus = { bet = (bet - 10_000L).coerceAtLeast(10_000L) },
                            onBetPlus = { bet += 10_000L },
                            onMultiplier = { multiplier = it },
                            onSpin = {
                                if (!spinning && spins > 0) {
                                    spinning = true
                                    spins--
                                    result = "I RULLI SONO IN MOVIMENTO..."
                                }
                            },
                            onFinished = { final ->
                                reels = final
                                val same = final.distinct().size
                                val win = when (same) {
                                    1 -> bet * multiplier * 50
                                    2 -> bet * multiplier * 4
                                    else -> bet * multiplier / 2
                                }
                                coins += win
                                result = when (same) {
                                    1 -> "JACKPOT! +${formatNumber(win)}"
                                    2 -> "COMBINAZIONE! +${formatNumber(win)}"
                                    else -> "NESSUNA COMBINAZIONE"
                                }
                                spinning = false
                            }
                        )
                        SideColumn(
                            Modifier.weight(0.21f),
                            listOf("⚡" to "OPERAZIONE\nFULMINE\n2g 14h", "🎁" to "BONUS\nGIORNALIERO\n14h", "▶" to "VIDEO BONUS\n+10"),
                            right = true
                        )
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        InfoPanel(Modifier.weight(1f), "GIRI DISPONIBILI", "🪖 $spins")
                        InfoPanel(Modifier.weight(1f), "SUPER SPIN", "🚀 ATTIVO", true)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(coins: Long, gems: Int) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
            .background(OliveDark).border(2.dp, Color(0xFF6E7A50), RoundedCornerShape(15.dp))
            .padding(7.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(45.dp).clip(RoundedCornerShape(12.dp)).background(Gold), contentAlignment = Alignment.Center) {
            Text("★", fontSize = 29.sp, color = OliveDark, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text("FRONTLINE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text("Lv. 23   560 / 1200 XP", color = Gold, fontWeight = FontWeight.Bold, fontSize = 8.sp)
        }
        ResourcePill("🪙", formatNumber(coins))
        Spacer(Modifier.width(3.dp))
        ResourcePill("💎", formatNumber(gems.toLong()))
        Spacer(Modifier.width(3.dp))
        Text("☰", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ResourcePill(icon: String, value: String) {
    Row(Modifier.clip(RoundedCornerShape(9.dp)).background(Color(0xFF5C7135)).padding(horizontal = 5.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 12.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 8.sp)
        Text("+", color = Gold, fontWeight = FontWeight.Black, fontSize = 13.sp)
    }
}

@Composable
private fun PayTable() {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(OliveDark)
        .border(2.dp, Color(0xFF65704A), RoundedCornerShape(15.dp)).padding(7.dp)) {
        Text("COMBINAZIONI VINCENTI", Modifier.fillMaxWidth(), color = Color.White, textAlign = TextAlign.Center, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                PayRow("🪖 🪖 🪖", "x2"); PayRow("🏅 🏅 🏅", "x3"); PayRow("📦 📦 📦", "x4"); PayRow("💣 💣 💣", "x6")
            }
            Column(Modifier.weight(1f)) {
                PayRow("🚁 🚁 🚁", "x10"); PayRow("🚜 🚜 🚜", "x15"); PayRow("✈️ ✈️ ✈️", "x20"); PayRow("⭐ ⭐ ⭐", "x50")
            }
        }
        Text("ⓘ  Le vincite vengono moltiplicate sulla puntata totale", Modifier.fillMaxWidth(), color = Color.LightGray, textAlign = TextAlign.Center, fontSize = 7.sp)
    }
}

@Composable
private fun PayRow(text: String, mult: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, Modifier.weight(1f), color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center)
        Text(mult, color = Gold, fontWeight = FontWeight.Black, fontSize = 11.sp)
    }
}

@Composable
private fun SideColumn(modifier: Modifier, items: List<Pair<String, String>>, right: Boolean = false) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEachIndexed { index, item ->
            val bg = when {
                right && index == 0 -> Purple
                right && index == 1 -> Blue
                right -> Color(0xFF2C5E88)
                else -> OliveDark
            }
            Column(Modifier.fillMaxWidth().height(95.dp).clip(RoundedCornerShape(15.dp)).background(bg)
                .border(2.dp, Color(0xFF65764B), RoundedCornerShape(15.dp)).padding(4.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(item.first, fontSize = 24.sp)
                Text(item.second, color = Color.White, fontWeight = FontWeight.Black, fontSize = 7.sp, textAlign = TextAlign.Center, lineHeight = 10.sp)
            }
        }
    }
}

@Composable
private fun SlotMachine(
    modifier: Modifier,
    reels: List<String>,
    spinning: Boolean,
    result: String,
    bet: Long,
    multiplier: Int,
    onBetMinus: () -> Unit,
    onBetPlus: () -> Unit,
    onMultiplier: (Int) -> Unit,
    onSpin: () -> Unit,
    onFinished: (List<String>) -> Unit
) {
    val stopped = remember { mutableStateListOf(reels[0], reels[1], reels[2]) }

    LaunchedEffect(spinning) {
        if (spinning) {
            stopped.clear()
            repeat(3) { stopped.add(reels[it]) }
        }
    }

    Column(modifier.clip(RoundedCornerShape(21.dp)).background(Color(0xFF62694D))
        .border(4.dp, Color(0xFF777D5B), RoundedCornerShape(21.dp)).padding(7.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color(0xFF3B412F)).padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("⚔  FRONTLINE  ⚔", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
            Text("COMMANDER", color = Gold, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().height(285.dp).clip(RoundedCornerShape(17.dp)).background(Frame).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            reels.forEachIndexed { index, symbol ->
                RealReel(
                    initial = symbol,
                    spinning = spinning,
                    stopDelay = 900L + index * 350L,
                    modifier = Modifier.weight(1f),
                    onStopped = { value ->
                        if (stopped.size >= 3) stopped[index] = value
                        if (index == 2) onFinished(stopped.toList())
                    }
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            BetControl(Modifier.weight(1f), "PUNTATA TOTALE", formatNumber(bet), onBetMinus, onBetPlus)
            Column(Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(OliveDark).padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("MOLTIPLICATORE", color = Color.LightGray, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf(1,2,3,4,5).forEach { m ->
                        Box(Modifier.clip(RoundedCornerShape(6.dp)).background(if (multiplier == m) Gold else Olive)
                            .clickable { onMultiplier(m) }.padding(horizontal = 4.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
                            Text("x$m", color = if (multiplier == m) OliveDark else Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
        Text(result, Modifier.padding(vertical = 6.dp), color = Gold, fontWeight = FontWeight.Black, fontSize = 9.sp, textAlign = TextAlign.Center)
        Button(onClick = onSpin, enabled = !spinning, modifier = Modifier.fillMaxWidth().height(65.dp), shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Color(0xFF8A2C22))) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SPIN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 27.sp)
                Text("Tocca per avviare i tre rulli", color = Color.White, fontSize = 7.sp)
            }
        }
    }
}

@Composable
private fun RealReel(initial: String, spinning: Boolean, stopDelay: Long, modifier: Modifier, onStopped: (String) -> Unit) {
    val offset = remember { Animatable(0f) }
    var visible by remember { mutableStateOf(listOf(symbols.random(), initial, symbols.random(), symbols.random(), symbols.random())) }

    LaunchedEffect(spinning) {
        if (spinning) {
            val start = System.currentTimeMillis()
            while (System.currentTimeMillis() - start < stopDelay) {
                visible = List(7) { symbols.random() }
                offset.snapTo(Random.nextFloat() * -130f)
                delay(55)
            }
            val final = symbols.random()
            visible = listOf(symbols.random(), symbols.random(), final, symbols.random(), symbols.random(), symbols.random(), symbols.random())
            offset.animateTo(-90f, tween(240, easing = FastOutSlowInEasing))
            onStopped(final)
        }
    }

    Box(modifier.clip(RoundedCornerShape(13.dp)).background(Cream).border(3.dp, Color(0xFF171A13), RoundedCornerShape(13.dp))) {
        LazyColumn(Modifier.fillMaxSize().offset(y = offset.value.dp), userScrollEnabled = false, horizontalAlignment = Alignment.CenterHorizontally) {
            itemsIndexed(visible) { _, value ->
                Box(Modifier.fillMaxWidth().height(55.dp), contentAlignment = Alignment.Center) {
                    Text(value, fontSize = 38.sp)
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0xFF77776B)).align(Alignment.Center))
    }
}

@Composable
private fun BetControl(modifier: Modifier, title: String, value: String, minus: () -> Unit, plus: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(13.dp)).background(OliveDark).padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color.LightGray, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = minus) { Text("−", color = Gold, fontSize = 21.sp) }
            Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            TextButton(onClick = plus) { Text("+", color = Gold, fontSize = 19.sp) }
        }
    }
}

@Composable
private fun InfoPanel(modifier: Modifier, title: String, value: String, blue: Boolean = false) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(if (blue) Blue else OliveDark).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 7.sp)
        Text(value, color = if (blue) Color.White else Gold, fontWeight = FontWeight.Black, fontSize = 16.sp)
    }
}

@Composable
private fun BottomNav() {
    Row(Modifier.fillMaxWidth().background(Color(0xFF12200E)).padding(horizontal = 4.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        NavItem("📦", "NEGOZIO")
        NavItem("🃏", "CARTE")
        NavItem("🎰", "SLOT", true)
        NavItem("🏠", "BASE")
        NavItem("🛡️", "ALLEANZA")
    }
}

@Composable
private fun NavItem(icon: String, label: String, active: Boolean = false) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).background(if (active) Color(0xFFE9D8F7) else Color.Transparent).padding(horizontal = 10.dp, vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 20.sp)
        Text(label, color = if (active) OliveDark else Color.White, fontWeight = FontWeight.Black, fontSize = 7.sp)
    }
}

private fun formatNumber(value: Long): String = String.format(Locale.ROOT, "%,d", value).replace(',', '.')
