# Frontline Commander Reborn - no custom shrinking rules required for debug/release v1.
