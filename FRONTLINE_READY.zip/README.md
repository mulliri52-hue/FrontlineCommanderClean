# Frontline Commander 0.7.0

Versione aggiornata del progetto Android.

- UI della slot riorganizzata per avvicinarsi molto di più al riferimento fornito.
- Slot centrale più grande e con cornice militare.
- Tabellone vincite sopra la macchina.
- Pannelli missioni/classifica/ricompense a sinistra.
- Evento/bonus/video a destra.
- Moltiplicatore scelto dal giocatore da x1 a x5.
- Capacità massima giri: 100.
- Ricarica: 1 giro ogni 3 minuti.
- Java/Kotlin target 17.
- Il banner pubblicitario non viene mostrato nella schermata principale per non coprire la UI.

Per la compilazione usa il workflow GitHub Actions già configurato nel repository.
