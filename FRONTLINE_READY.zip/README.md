# Frontline Commander Reborn

Nuova base del progetto Android, ricostruita da zero prendendo come riferimento lo screenshot della schermata slot.

## Obiettivo della v1
- UI mobile-first
- 3 rulli
- puntata e moltiplicatore
- giri disponibili
- combinazioni vincenti
- missioni / bonus / video
- navigazione Negozio, Carte, Slot, Base, Alleanza
- build automatica tramite GitHub Actions

## Build
GitHub Actions usa Java 17 e Gradle 8.11.1. Non serve Android Studio sul telefono.
