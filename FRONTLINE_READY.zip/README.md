# Frontline Commander

Android game prototype built with Kotlin + Jetpack Compose.

## Build

The GitHub Actions workflow installs Java 17 and uses the Gradle 8.13 wrapper, then builds `assembleDebug`. Java and Kotlin are both targeted to JVM 17.

## AdMob

The project contains a banner integration dependency. The manifest currently uses Google's test App ID. Replace it with the AdMob **App ID** (`ca-app-pub-...~...`) before release, and use the production banner ad unit only for release builds. During development, use Google's test banner ID.


## Frontline Commander V2
- Rebuilt the main screen around a large military slot-machine layout.
- Added a winning-combinations board above the reels.
- Added animated reel transitions and large SPIN control.
- Added multiplier/payout panels, spin counter with 3-minute recharge, bonus-video area, event cards and bottom navigation.
- Preserved local persistence and existing audio/rewarded-ad logic.
- Version 0.5.0 / versionCode 5.
