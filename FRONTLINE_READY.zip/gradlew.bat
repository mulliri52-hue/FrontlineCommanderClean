@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Errore: Gradle 9.7 non e' disponibile.
  exit /b 1
)
gradle %*
