package com.frontline.commander

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private val Sky = Color(0xFF63A9C0)
private val Grass = Color(0xFF6E964E)
private val GrassDark = Color(0xFF2B481E)
private val Olive = Color(0xFF344820)
private val OliveDark = Color(0xFF17230F)
private val MetalDark = Color(0xFF3A3C2C)
private val MetalLight = Color(0xFFAAA982)
private val Cream = Color(0xFFFFF6DE)
private val Gold = Color(0xFFFFC62E)
private val Red = Color(0xFFE0432E)
private val Blue = Color(0xFF147FB1)
private val Purple = Color(0xFF7040A0)

private const val BASE_BET = 100_000
private const val MAX_SPINS = 100
private const val START_SPINS = 17
private const val RECHARGE_MS = 3 * 60 * 1000L

private data class Symbol(val icon: String, val name: String)
private data class WinRule(val icon: String, val multiplier: Int)

private val symbols = listOf(
    Symbol("🪖", "ELMETTO"), Symbol("🎖️", "MEDAGLIA"), Symbol("🚁", "ELICOTTERO"),
    Symbol("📦", "CASSA"), Symbol("✈️", "AEREO"), Symbol("💣", "GRANATA"),
    Symbol("⭐", "STELLA"), Symbol("🛡️", "SCUDO")
)

private val winRules = listOf(
    WinRule("🪖", 2), WinRule("🎖️", 3), WinRule("📦", 4), WinRule("💣", 6),
    WinRule("🚁", 10), WinRule("🛡️", 15), WinRule("✈️", 20), WinRule("⭐", 50)
)

private enum class Screen { SLOT, SHOP, CARDS, BASE, ALLIANCE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrontlineApp() }
    }
}

private class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("frontline_game", Context.MODE_PRIVATE)
    var coins: Int
        get() = prefs.getInt("coins", 8_450_000)
        set(v) { prefs.edit().putInt("coins", v.coerceAtLeast(0)).apply() }
    var spins: Int
        get() = prefs.getInt("spins", START_SPINS)
        set(v) { prefs.edit().putInt("spins", v.coerceIn(0, MAX_SPINS)).apply() }
    var xp: Int
        get() = prefs.getInt("xp", 560)
        set(v) { prefs.edit().putInt("xp", v.coerceAtLeast(0)).apply() }
    var lastRecharge: Long
        get() = prefs.getLong("recharge", System.currentTimeMillis())
        set(v) { prefs.edit().putLong("recharge", v).apply() }
}

@Composable
private fun FrontlineApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { GameStore(context) }
    val audio = remember { GameSound(context) }

    var screen by rememberSaveable { mutableStateOf(Screen.SLOT) }
    var coins by remember { mutableIntStateOf(store.coins) }
    var spins by remember { mutableIntStateOf(store.spins) }
    var xp by remember { mutableIntStateOf(store.xp) }
    var multiplier by rememberSaveable { mutableIntStateOf(1) }
    var spinning by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf(listOf("🪖", "🎖️", "🚁")) }
    var message by rememberSaveable { mutableStateOf("PRONTO AL LANCIO, COMANDANTE!") }
    var lastWin by rememberSaveable { mutableIntStateOf(0) }
    var rechargeSeconds by remember { mutableIntStateOf(0) }
    var soundOn by rememberSaveable { mutableStateOf(true) }

    fun save() {
        store.coins = coins
        store.spins = spins
        store.xp = xp
    }

    DisposableEffect(Unit) { onDispose { audio.release() } }

    LaunchedEffect(Unit) {
        while (true) {
            if (spins < MAX_SPINS) {
                val elapsed = max(0L, System.currentTimeMillis() - store.lastRecharge)
                val gained = (elapsed / RECHARGE_MS).toInt()
                if (gained > 0) {
                    spins = min(MAX_SPINS, spins + gained)
                    store.lastRecharge += gained * RECHARGE_MS
                    save()
                }
                val remaining = max(0L, RECHARGE_MS - (System.currentTimeMillis() - store.lastRecharge))
                rechargeSeconds = (remaining / 1000L).toInt()
            } else rechargeSeconds = 0
            delay(1000)
        }
    }

    LaunchedEffect(spinning, target) {
        if (!spinning) return@LaunchedEffect
        delay(3600)
        val bet = BASE_BET * multiplier
        val triple = target[0] == target[1] && target[1] == target[2]
        val pair = target[0] == target[1] || target[1] == target[2] || target[0] == target[2]
        lastWin = when {
            triple -> bet * (winRules.firstOrNull { it.icon == target[0] }?.multiplier ?: 2)
            pair -> bet * 2
            else -> 0
        }
        if (lastWin > 0) {
            coins += lastWin
            xp += 15
            message = if (triple) "VITTORIA! +${compact(lastWin)}" else "DOPPIA! +${compact(lastWin)}"
            audio.win()
        } else {
            xp += 5
            message = "NESSUNA COMBINAZIONE"
            audio.lose()
        }
        save()
        spinning = false
    }

    fun spin() {
        val bet = BASE_BET * multiplier
        if (spinning || spins <= 0 || coins < bet) return
        if (spins == MAX_SPINS) store.lastRecharge = System.currentTimeMillis()
        target = List(3) { symbols[Random.nextInt(symbols.size)].icon }
        spins--
        coins -= bet
        lastWin = 0
        message = "I RULLI STANNO GIRANDO..."
        spinning = true
        save()
        audio.spin()
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Olive)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Sky, Grass, GrassDark)))) {
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { BottomNav(screen) { screen = it } }
            ) { padding ->
                Column(
                    Modifier.fillMaxSize().padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Header(xp, coins, soundOn) {
                        soundOn = !soundOn
                        audio.setEnabled(soundOn)
                    }
                    Spacer(Modifier.height(8.dp))
                    when (screen) {
                        Screen.SLOT -> SlotScreen(
                            target, spinning, multiplier, spins, rechargeSeconds, message, lastWin,
                            { multiplier = it }, ::spin
                        )
                        Screen.SHOP -> SectionScreen("📦 NEGOZIO", "Rifornimenti", "CASSE • EQUIPAGGIAMENTO • POTENZIAMENTI")
                        Screen.CARDS -> SectionScreen("🃏 CARTE", "Collezione", "CARTE DEL FRONTE • RARITÀ • BONUS")
                        Screen.BASE -> SectionScreen("🏠 BASE", "Quartier generale", "COSTRUISCI • POTENZIA • DIFENDI")
                        Screen.ALLIANCE -> SectionScreen("🛡️ ALLEANZA", "La tua squadra", "SQUADRA • CLASSIFICA • MISSIONI")
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(xp: Int, coins: Int, soundOn: Boolean, onSound: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp))
            .background(OliveDark).border(3.dp, Color(0xFF5C7440), RoundedCornerShape(22.dp))
            .padding(7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(Gold), contentAlignment = Alignment.Center) {
            Text("🪖", fontSize = 34.sp)
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("FRONTLINE", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("LV. 23", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(8.dp))
                Text("$xp/1200 XP", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        ResourcePill("🪙", compact(coins))
        Spacer(Modifier.width(4.dp))
        ResourcePill("💎", "1.250")
        Text(if (soundOn) "🔊" else "🔇", Modifier.clickable { onSound() }.padding(5.dp), fontSize = 18.sp)
    }
}

@Composable
private fun ResourcePill(icon: String, value: String) {
    Row(
        Modifier.clip(RoundedCornerShape(13.dp)).background(Color(0xFF64763E)).padding(horizontal = 7.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 14.sp)
        Spacer(Modifier.width(3.dp))
        Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
        Text("+", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun SlotScreen(
    target: List<String>, spinning: Boolean, multiplier: Int, spins: Int, recharge: Int,
    message: String, lastWin: Int, onMultiplier: (Int) -> Unit, onSpin: () -> Unit
) {
    WinningBoard()
    Spacer(Modifier.height(8.dp))
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val side = if (maxWidth < 390.dp) 62.dp else 92.dp
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.width(side), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                SideCard("🎁", "MISSIONI", "2")
                SideCard("🏆", "CLASSIFICA", "2g 14h")
                SideCard("🎁", "RICOMPENSE", "14h")
            }
            SlotMachine(target, spinning, multiplier, message, lastWin, maxWidth < 390.dp, onMultiplier, onSpin, Modifier.weight(1f))
            Column(Modifier.width(side), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                EventCard("⚡", "OPERAZIONE\nFULMINE", "2g 14h", Purple)
                EventCard("🎁", "BONUS\nGIORNALIERO", "14h", Blue)
                EventCard("▶", "VIDEO\nBONUS", "+10", Color(0xFF28638C))
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        CounterCard(spins, recharge, Modifier.weight(1f))
        SuperSpinCard(Modifier.weight(1f))
    }
}

@Composable
private fun WinningBoard() {
    Card(
        Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(23.dp)),
        shape = RoundedCornerShape(23.dp),
        colors = CardDefaults.cardColors(containerColor = Olive),
        border = BorderStroke(3.dp, MetalLight)
    ) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 8.dp)) {
            Text("COMBINAZIONI VINCENTI", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    WinLine("🪖", 2); WinLine("🎖️", 3); WinLine("📦", 4); WinLine("💣", 6)
                }
                Column(Modifier.weight(1f)) {
                    WinLine("🚁", 10); WinLine("🛡️", 15); WinLine("✈️", 20); WinLine("⭐", 50)
                }
            }
            Text("ⓘ  Le vincite vengono moltiplicate sulla puntata totale", color = Color(0xFFD9DFC9),
                fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun WinLine(icon: String, multiplier: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$icon $icon $icon", fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text("×$multiplier", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun SlotMachine(
    target: List<String>, spinning: Boolean, multiplier: Int, message: String, lastWin: Int,
    compact: Boolean, onMultiplier: (Int) -> Unit, onSpin: () -> Unit, modifier: Modifier
) {
    Box(
        modifier.shadow(14.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF858667), MetalDark, Color(0xFF5D624A))))
            .border(5.dp, Color(0xFF313426), RoundedCornerShape(30.dp)).padding(7.dp)
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(if (compact) 70.dp else 82.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF73785B), Color(0xFF3B4030))))
                    .border(3.dp, MetalLight, RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("⚔  FRONTLINE\nCOMMANDER  ⚔", color = Cream,
                    fontSize = if (compact) 16.sp else 19.sp, lineHeight = if (compact) 17.sp else 20.sp,
                    fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(7.dp))
            ReelsWindow(target, spinning, compact)
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BetBox(compact, multiplier, Modifier.weight(1f))
                MultiplierBox(multiplier, onMultiplier, Modifier.weight(1f))
            }
            Text(if (spinning) "I RULLI STANNO GIRANDO..." else message, color = Gold,
                fontWeight = FontWeight.Black, fontSize = if (compact) 9.sp else 11.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
            if (!spinning && lastWin > 0) {
                Text("VINCITA +${compact(lastWin)}", color = Color.White, fontWeight = FontWeight.Black,
                    fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Button(
                onClick = onSpin, enabled = !spinning,
                modifier = Modifier.fillMaxWidth().height(if (compact) 86.dp else 92.dp),
                shape = RoundedCornerShape(24.dp), border = BorderStroke(4.dp, Color(0xFF9A291C)),
                colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Color(0xFF9A3B31))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (spinning) "GIRANDO..." else "SPIN", color = Color.White,
                        fontSize = if (compact) 30.sp else 35.sp, fontWeight = FontWeight.Black)
                    if (!spinning) Text("TIENI PREMUTO PER SPIN AUTOMATICI", color = Color.White, fontSize = 7.sp)
                }
            }
        }
    }
}

@Composable
private fun ReelsWindow(target: List<String>, spinning: Boolean, compact: Boolean) {
    Box(
        Modifier.fillMaxWidth().height(if (compact) 285.dp else 330.dp)
            .clip(RoundedCornerShape(26.dp)).background(Color(0xFF151812))
            .border(7.dp, Color(0xFF2B3024), RoundedCornerShape(26.dp)).padding(6.dp)
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawRect(Brush.verticalGradient(listOf(Sky, Color(0xFFA3C988), Color(0xFF547A3C))), size = size)
            drawCircle(Color(0xFFFFD66A), radius = size.width * .075f,
                center = Offset(size.width * .82f, size.height * .12f))
            drawRect(Color(0xFF456E39), topLeft = Offset(0f, size.height * .72f),
                size = Size(size.width, size.height * .28f))
            repeat(6) { i ->
                val x = size.width * (0.06f + i * 0.18f)
                drawRect(Color(0xFF684A2E), topLeft = Offset(x, size.height * .56f),
                    size = Size(size.width * .025f, size.height * .18f))
                drawCircle(Color(0xFF315C2C), radius = size.width * .075f,
                    center = Offset(x + size.width * .01f, size.height * .54f))
            }
        }
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            for (i in 0..2) AnimatedReel(target[i], spinning, i, Modifier.weight(1f).fillMaxHeight())
        }
        Box(Modifier.fillMaxWidth().height(5.dp).align(Alignment.Center).background(Color(0xFF6E6B58)))
    }
}

@Composable
private fun AnimatedReel(finalSymbol: String, spinning: Boolean, index: Int, modifier: Modifier) {
    val travel = 64f
    val offset = remember { Animatable(0f) }
    var visible by remember { mutableStateOf(List(7) { symbols[(index + it) % symbols.size].icon }) }

    LaunchedEffect(spinning, finalSymbol) {
        if (!spinning) {
            visible = listOf(symbols.random().icon, finalSymbol, symbols.random().icon, symbols.random().icon, symbols.random().icon)
            offset.snapTo(0f)
            return@LaunchedEffect
        }
        delay(index * 170L)
        val stopTime = 2300L + index * 450L
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < stopTime) {
            visible = List(9) { symbols[Random.nextInt(symbols.size)].icon }
            offset.snapTo(-travel)
            offset.animateTo(travel, tween(95))
            offset.snapTo(-travel)
            delay(5)
        }
        visible = listOf(symbols.random().icon, symbols.random().icon, finalSymbol, symbols.random().icon, symbols.random().icon)
        offset.snapTo(-travel)
        offset.animateTo(0f, tween(260))
    }

    Box(modifier.clip(RoundedCornerShape(18.dp)).background(Cream)
        .border(3.dp, Color(0xFF292C21), RoundedCornerShape(18.dp)).clipToBounds()) {
        Column(
            Modifier.fillMaxSize().offset(y = offset.value.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            visible.forEachIndexed { i, icon ->
                Text(icon, fontSize = if (i == 2) 48.sp else 34.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun BetBox(compact: Boolean, multiplier: Int, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(OliveDark).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("PUNTATA TOTALE", color = Color(0xFFC9CEBE), fontSize = 8.sp, fontWeight = FontWeight.Black)
        Text(compact(BASE_BET * multiplier), color = Color.White,
            fontSize = if (compact) 15.sp else 18.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun MultiplierBox(selected: Int, onChange: (Int) -> Unit, modifier: Modifier) {
    Row(modifier.clip(RoundedCornerShape(16.dp)).background(OliveDark).padding(horizontal = 3.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("−", color = Color.White, fontSize = 23.sp,
            modifier = Modifier.clickable { onChange(max(1, selected - 1)) }.padding(4.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("MOLTIPLICATORE", color = Color(0xFFC9CEBE), fontSize = 7.sp, fontWeight = FontWeight.Black)
            Text("X$selected", color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
        Text("+", color = Color.White, fontSize = 23.sp,
            modifier = Modifier.clickable { onChange(min(5, selected + 1)) }.padding(4.dp))
    }
}

@Composable
private fun SideCard(icon: String, title: String, value: String) {
    Card(Modifier.fillMaxWidth().height(105.dp).shadow(5.dp, RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = OliveDark),
        border = BorderStroke(2.dp, Color(0xFF647746))) {
        Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 28.sp)
            Text(title, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Text(value, color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun EventCard(icon: String, title: String, value: String, color: Color) {
    Card(Modifier.fillMaxWidth().height(112.dp).shadow(5.dp, RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = color),
        border = BorderStroke(2.dp, Color(0xFF71806B))) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 29.sp)
            Text(title, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Text(value, color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun CounterCard(spins: Int, recharge: Int, modifier: Modifier) {
    Card(modifier.height(86.dp), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = OliveDark),
        border = BorderStroke(2.dp, Color(0xFF647746))) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text("GIRI DISPONIBILI", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🪖", fontSize = 22.sp)
                Text("$spins", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
                Text("+", color = Color.White, fontSize = 20.sp)
            }
            Text(if (spins == MAX_SPINS) "CAPACITÀ 100"
                else "+1 GIRO TRA ${recharge / 60}:${(recharge % 60).toString().padStart(2, '0')}",
                color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SuperSpinCard(modifier: Modifier) {
    Card(modifier.height(86.dp), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Blue),
        border = BorderStroke(2.dp, Color(0xFF7AA7B9))) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text("🚀", fontSize = 27.sp)
            Text("SUPER SPIN", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Text("ATTIVO", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun BottomNav(selected: Screen, onSelect: (Screen) -> Unit) {
    val items = listOf(
        "📦" to ("NEGOZIO" to Screen.SHOP), "🃏" to ("CARTE" to Screen.CARDS),
        "🎰" to ("SLOT" to Screen.SLOT), "🏠" to ("BASE" to Screen.BASE),
        "🛡️" to ("ALLEANZA" to Screen.ALLIANCE)
    )
    Row(Modifier.fillMaxWidth().background(Color(0xFF14210F)).padding(horizontal = 6.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        items.forEach { (icon, pair) ->
            val active = selected == pair.second
            Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).clickable { onSelect(pair.second) }
                .background(if (active) Color(0xFFEDE0F7) else Color.Transparent).padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text(icon, fontSize = if (active) 28.sp else 23.sp)
                Text(pair.first, color = if (active) Color(0xFF1E241A) else Color(0xFFD5D8C8),
                    fontSize = 8.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun SectionScreen(title: String, subtitle: String, value: String) {
    Box(Modifier.fillMaxSize().padding(vertical = 80.dp), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(12.dp), colors = CardDefaults.cardColors(containerColor = OliveDark),
            shape = RoundedCornerShape(28.dp), border = BorderStroke(3.dp, MetalLight)) {
            Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                Text(subtitle, color = Color(0xFFD8DEC9), fontSize = 16.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(22.dp))
                Text(value, color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            }
        }
    }
}

private fun compact(value: Int): String = when {
    value >= 1_000_000 -> "${value / 1_000_000}.${(value / 100_000) % 10}M"
    value >= 1_000 -> "${value / 1_000}.${(value / 100) % 10}K"
    else -> value.toString()
}

private class GameSound(context: Context) {
    private val pool: SoundPool
    private val music: MediaPlayer?
    private val spinId: Int
    private val winId: Int
    private val loseId: Int
    private var enabled = true

    init {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        pool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(4).build()
        spinId = pool.load(context, R.raw.slot_spin, 1)
        winId = pool.load(context, R.raw.slot_win, 1)
        loseId = pool.load(context, R.raw.slot_lose, 1)
        music = MediaPlayer.create(context, R.raw.frontline_music)?.apply {
            isLooping = true
            setVolume(.18f, .18f)
        }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        if (enabled && music?.isPlaying == false) music.start()
        if (!enabled && music?.isPlaying == true) music.pause()
    }

    fun spin() { if (enabled) pool.play(spinId, .55f, .55f, 1, 0, 1f) }
    fun win() { if (enabled) pool.play(winId, .75f, .75f, 1, 0, 1.05f) }
    fun lose() { if (enabled) pool.play(loseId, .4f, .4f, 1, 0, .9f) }

    fun release() {
        if (music?.isPlaying == true) music.stop()
        music?.release()
        pool.release()
    }
}
