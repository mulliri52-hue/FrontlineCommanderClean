package com.frontline.commander

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlin.math.max

private val Olive = Color(0xFF405522)
private val OliveDark = Color(0xFF203414)
private val OlivePanel = Color(0xFF34451F)
private val Metal = Color(0xFF77775A)
private val MetalLight = Color(0xFFA8A887)
private val MetalDark = Color(0xFF343629)
private val Gold = Color(0xFFFFC52D)
private val GoldDark = Color(0xFF9A6916)
private val Red = Color(0xFFE3412E)
private val RedDark = Color(0xFF8C241B)
private val Blue = Color(0xFF1885B9)
private val Purple = Color(0xFF6E3CA0)
private val Cream = Color(0xFFFFF7DD)
private val Ink = Color(0xFF202419)

private const val MAX_SPINS = 100
private const val STARTING_SPINS = 17
private const val SPIN_RECHARGE_MS = 3 * 60 * 1000L

private data class Symbol(val icon: String, val name: String)
private data class WinRule(val symbol: String, val label: String, val multiplier: Int)

private val slotSymbols = listOf(
    Symbol("🪖", "ELMETTO"),
    Symbol("🎖️", "MEDAGLIA"),
    Symbol("🚁", "ELICOTTERO"),
    Symbol("🛡️", "SCUDO"),
    Symbol("📦", "CASSA"),
    Symbol("✈️", "AEREO"),
    Symbol("💣", "GRANATA"),
    Symbol("⭐", "STELLA")
)

private val winRules = listOf(
    WinRule("🪖", "ELMETTI", 2),
    WinRule("📦", "CASSE", 4),
    WinRule("🚁", "ELICOTTERI", 10),
    WinRule("✈️", "AEREI", 20),
    WinRule("🛡️", "SCUDI", 15),
    WinRule("⭐", "STELLE", 50)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrontlineApp() }
    }
}

private class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("frontline_game", Context.MODE_PRIVATE)
    var coins: Int get() = prefs.getInt("coins", 8_450_000); set(v) = prefs.edit().putInt("coins", v.coerceAtLeast(0)).apply()
    var spins: Int get() = prefs.getInt("spins", STARTING_SPINS).coerceIn(0, MAX_SPINS); set(v) = prefs.edit().putInt("spins", v.coerceIn(0, MAX_SPINS)).apply()
    var power: Int get() = prefs.getInt("power", 18); set(v) = prefs.edit().putInt("power", v.coerceAtLeast(0)).apply()
    var maxPower: Int get() = prefs.getInt("maxPower", 50); set(v) = prefs.edit().putInt("maxPower", v.coerceAtLeast(1)).apply()
    var xp: Int get() = prefs.getInt("xp", 560); set(v) = prefs.edit().putInt("xp", v.coerceAtLeast(0)).apply()
    var streak: Int get() = prefs.getInt("streak", 1); set(v) = prefs.edit().putInt("streak", v.coerceAtLeast(1)).apply()
    var lastSpinRecharge: Long get() = prefs.getLong("last_spin_recharge", System.currentTimeMillis()); set(v) = prefs.edit().putLong("last_spin_recharge", v).apply()
    var soundEnabled: Boolean get() = prefs.getBoolean("sound_enabled", true); set(v) = prefs.edit().putBoolean("sound_enabled", v).apply()
}

@Composable
fun FrontlineApp() {
    val context = LocalContext.current
    val store = remember { GameStore(context) }
    val sound = remember { GameSound(context) }
    var coins by remember { mutableIntStateOf(store.coins) }
    var spins by remember { mutableIntStateOf(store.spins) }
    var power by remember { mutableIntStateOf(store.power) }
    var xp by remember { mutableIntStateOf(store.xp) }
    var reels by remember { mutableStateOf(listOf("🪖", "🎖️", "🚁")) }
    var spinning by remember { mutableStateOf(false) }
    var rechargeSeconds by remember { mutableIntStateOf(0) }
    var selectedMultiplier by rememberSaveable { mutableIntStateOf(1) }
    var lastMultiplier by rememberSaveable { mutableIntStateOf(0) }
    var lastWinCoins by rememberSaveable { mutableIntStateOf(0) }
    var message by rememberSaveable { mutableStateOf("PRONTO AL LANCIO, COMANDANTE!") }
    var lastResult by rememberSaveable { mutableStateOf("") }
    var soundEnabled by remember { mutableStateOf(store.soundEnabled) }
    val effectiveBet = 100_000 * selectedMultiplier

    fun persist() {
        store.coins = coins
        store.spins = spins
        store.power = power
        store.xp = xp
        store.soundEnabled = soundEnabled
    }

    DisposableEffect(Unit) { onDispose { sound.release() } }
    LaunchedEffect(soundEnabled) { sound.setEnabled(soundEnabled) }

    LaunchedEffect(Unit) {
        while (true) {
            if (spins >= MAX_SPINS) {
                rechargeSeconds = 0
            } else {
                val elapsed = max(0L, System.currentTimeMillis() - store.lastSpinRecharge)
                val gained = (elapsed / SPIN_RECHARGE_MS).toInt()
                if (gained > 0) {
                    val actual = minOf(gained, MAX_SPINS - spins)
                    spins += actual
                    store.lastSpinRecharge += actual * SPIN_RECHARGE_MS
                    persist()
                }
                rechargeSeconds = max(0L, SPIN_RECHARGE_MS - max(0L, System.currentTimeMillis() - store.lastSpinRecharge)).div(1000L).toInt()
            }
            delay(1000)
        }
    }

    LaunchedEffect(spinning) {
        if (!spinning) return@LaunchedEffect
        val symbols = slotSymbols.map { it.icon }
        val bet = effectiveBet

        // Real reel animation: each reel is visibly advanced independently and stops at a different time.
        val stopTimes = listOf(1450L, 1850L, 2250L)
        val startedAt = System.currentTimeMillis()
        var elapsed = 0L
        while (elapsed < stopTimes.last()) {
            val next = reels.toMutableList()
            for (i in 0..2) {
                if (elapsed < stopTimes[i]) next[i] = symbols.random()
            }
            reels = next
            delay(85)
            elapsed = System.currentTimeMillis() - startedAt
        }

        val final = List(3) { symbols.random() }
        reels = final
        val first = final[0]
        val second = final[1]
        val third = final[2]
        val same = first == second && second == third
        val pair = first == second || second == third || first == third

        when {
            same -> {
                val ruleMultiplier = winRules.firstOrNull { it.symbol == first }?.multiplier ?: 2
                val gain = bet * ruleMultiplier
                lastMultiplier = ruleMultiplier
                lastWinCoins = gain
                lastResult = "$first  $second  $third"
                coins += gain
                xp += 25 * ruleMultiplier
                power = (power + 2).coerceAtMost(store.maxPower)
                message = "🏆 VITTORIA! +${compactNumber(gain)}"
                if (soundEnabled) sound.win()
            }
            pair -> {
                val gain = bet * 2
                lastMultiplier = 2
                lastWinCoins = gain
                lastResult = "$first  $second  $third"
                coins += gain
                xp += 15
                message = "🎯 DOPPIA! +${compactNumber(gain)}"
                if (soundEnabled) sound.win()
            }
            else -> {
                lastMultiplier = 0
                lastWinCoins = 0
                lastResult = "$first  $second  $third"
                xp += 5
                message = "NESSUNA COMBINAZIONE"
                if (soundEnabled) sound.lose()
            }
        }
        persist()
        spinning = false
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Olive)) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = { BottomGameBar() }
        ) { padding ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Brush.verticalGradient(listOf(Color(0xFF78B7CF), Color(0xFF86B56C), Color(0xFF3B5728), Color(0xFF1B2A15))))
            ) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    TopBar(xp, coins, power, soundEnabled) {
                        soundEnabled = !soundEnabled
                        persist()
                        if (soundEnabled) sound.tap()
                    }
                    Spacer(Modifier.height(7.dp))
                    WinningBoard()
                    Spacer(Modifier.height(8.dp))
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val compact = maxWidth < 430.dp
                        val leftWidth = if (compact) 67.dp else 86.dp
                        val rightWidth = if (compact) 74.dp else 94.dp
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 7.dp)) {
                            Column(Modifier.width(leftWidth), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                MiniSideCard("🎁", "MISSIONI", "2")
                                MiniSideCard("🏆", "CLASSIFICA", "2g 14h")
                                MiniSideCard("🎁", "RICOMPENSE", "14h")
                            }
                            SlotMachine(
                                reels = reels,
                                spinning = spinning,
                                multiplier = lastMultiplier,
                                selectedMultiplier = selectedMultiplier,
                                result = lastResult,
                                winCoins = lastWinCoins,
                                message = message,
                                compact = compact,
                                onMultiplierChange = { selectedMultiplier = it },
                                onSpin = {
                                    if (!spinning && spins > 0 && coins >= effectiveBet) {
                                        spinning = true
                                        if (spins == MAX_SPINS) store.lastSpinRecharge = System.currentTimeMillis()
                                        spins -= 1
                                        coins -= effectiveBet
                                        power = (power - 1).coerceAtLeast(0)
                                        lastMultiplier = 0
                                        lastWinCoins = 0
                                        lastResult = ""
                                        message = "I RULLI STANNO GIRANDO..."
                                        persist()
                                        if (soundEnabled) sound.spin()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                            Column(Modifier.width(rightWidth), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                SideEvent("⚡", "OPERAZIONE FULMINE", "2g 14h", Purple, Modifier.fillMaxWidth().height(if (compact) 142.dp else 150.dp))
                                SideEvent("🎁", "BONUS GIORNALIERO", "14h", Blue, Modifier.fillMaxWidth().height(if (compact) 118.dp else 126.dp))
                                SideEvent("▶", "VIDEO BONUS", "+10", Color(0xFF28618A), Modifier.fillMaxWidth().height(if (compact) 100.dp else 108.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SpinCounter(spins, rechargeSeconds, Modifier.weight(1f))
                        SuperSpinCard(Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
private fun TopBar(xp: Int, coins: Int, power: Int, soundEnabled: Boolean, onSound: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(7.dp, RoundedCornerShape(19.dp))
            .clip(RoundedCornerShape(19.dp))
            .background(OliveDark)
            .border(2.dp, Color(0xFF667943), RoundedCornerShape(19.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(53.dp).clip(RoundedCornerShape(15.dp)).background(Gold).border(2.dp, GoldDark, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Text("🪖", fontSize = 31.sp)
        }
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Text("FRONTLINE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("LV. 23", color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp)
                Spacer(Modifier.width(7.dp))
                Text("$xp/1200 XP", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        ResourcePill("🪙", compactNumber(coins))
        Spacer(Modifier.width(4.dp))
        ResourcePill("💎", "1.250")
        Text(if (soundEnabled) "🔊" else "🔇", Modifier.clickable { onSound() }.padding(4.dp), fontSize = 17.sp)
    }
}

@Composable
private fun ResourcePill(icon: String, value: String) {
    Row(
        Modifier.clip(RoundedCornerShape(11.dp)).background(Color(0xFF66773C)).border(1.dp, Color(0xFF8D9B5A), RoundedCornerShape(11.dp)).padding(horizontal = 5.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 14.sp)
        Spacer(Modifier.width(2.dp))
        Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 9.sp)
        Text("+", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.padding(start = 2.dp))
    }
}

private fun compactNumber(value: Int): String = when {
    value >= 1_000_000 -> "${value / 1_000_000}.${(value / 100_000) % 10}M"
    value >= 1_000 -> "${value / 1_000}.${(value / 100) % 10}K"
    else -> value.toString()
}

@Composable
private fun WinningBoard() {
    Card(
        Modifier.fillMaxWidth().shadow(7.dp, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF344526)),
        border = BorderStroke(3.dp, Color(0xFF707A4D))
    ) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 8.dp)) {
            Text("COMBINAZIONI VINCENTI", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    WinLine(winRules[0]); WinLine(winRules[1]); WinLine(winRules[2])
                }
                Column(Modifier.weight(1f)) {
                    WinLine(winRules[3]); WinLine(winRules[4]); WinLine(winRules[5])
                }
            }
            Text("ⓘ  Le vincite vengono moltiplicate sulla puntata totale", color = Color(0xFFD8DDC8), fontSize = 8.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun WinLine(rule: WinRule) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${rule.symbol} ${rule.symbol} ${rule.symbol}", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text("×${rule.multiplier}", color = Gold, fontWeight = FontWeight.Black, fontSize = 14.sp)
    }
}

@Composable
private fun SlotMachine(
    reels: List<String>,
    spinning: Boolean,
    multiplier: Int,
    selectedMultiplier: Int,
    result: String,
    winCoins: Int,
    message: String,
    compact: Boolean,
    onMultiplierChange: (Int) -> Unit,
    onSpin: () -> Unit,
    modifier: Modifier
) {
    val outerRadius = if (compact) 24.dp else 28.dp
    Box(
        modifier
            .shadow(12.dp, RoundedCornerShape(outerRadius))
            .clip(RoundedCornerShape(outerRadius))
            .background(Color(0xFF657552))
            .border(5.dp, Color(0xFF3A402D), RoundedCornerShape(outerRadius))
    ) {
        // Scenic background sits BEHIND the slot frame, matching the reference composition.
        Column(Modifier.fillMaxWidth().padding(7.dp)) {
            Box(
                Modifier.fillMaxWidth().height(if (compact) 66.dp else 70.dp)
                    .clip(RoundedCornerShape(23.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF77795B), Color(0xFF3A3D2E))))
                    .border(3.dp, Color(0xFFA2A078), RoundedCornerShape(23.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("⚔  FRONTLINE  ⚔\nCOMMANDER  ⚔", color = Cream, fontWeight = FontWeight.Black, fontSize = if (compact) 15.sp else 17.sp, textAlign = TextAlign.Center, lineHeight = 17.sp)
            }
            Spacer(Modifier.height(7.dp))
            Box(
                Modifier.fillMaxWidth().height(if (compact) 300.dp else 320.dp)
                    .clip(RoundedCornerShape(23.dp))
                    .background(Color(0xFF151811))
                    .border(7.dp, Color(0xFF2D3025), RoundedCornerShape(23.dp))
                    .padding(7.dp)
            ) {
                // Background visible around the reels.
                Box(Modifier.fillMaxSize()) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        drawRect(Color(0xFF9BC6D5), size = size)
                        drawCircle(Color(0xFFFFD56A), radius = w * 0.10f, center = Offset(w * 0.82f, h * 0.13f))
                        drawOval(Color(0xFF8DB36A), topLeft = Offset(-w * 0.20f, h * 0.30f), size = Size(w * 0.85f, h * 0.55f))
                        drawOval(Color(0xFF648D4A), topLeft = Offset(w * 0.34f, h * 0.28f), size = Size(w * 0.82f, h * 0.60f))
                        drawRect(Color(0xFF456B38), topLeft = Offset(0f, h * 0.68f), size = Size(w, h * 0.32f))
                        listOf(0.07f, 0.93f).forEach { x ->
                            drawRect(Color(0xFF5B402B), topLeft = Offset(w * x - w * 0.018f, h * 0.50f), size = Size(w * 0.036f, h * 0.20f))
                            drawCircle(Color(0xFF31582D), radius = w * 0.065f, center = Offset(w * x, h * 0.47f))
                        }
                    }
                }
                Row(Modifier.fillMaxSize().zIndex(2f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    reels.forEachIndexed { i, icon ->
                        AnimatedReel(icon, spinning, i, Modifier.weight(1f).fillMaxHeight())
                    }
                }
                Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0xFF706A50)).align(Alignment.Center).zIndex(4f))
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                InfoBox("PUNTATA TOTALE", "${compactNumber(100_000 * selectedMultiplier)}", Modifier.weight(1f))
                MultiplierBox(selectedMultiplier, onMultiplierChange, Modifier.weight(1.05f))
            }
            Text(if (spinning) "I RULLI STANNO GIRANDO..." else message, color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
            if (!spinning && multiplier > 0) Text("$result  •  +${compactNumber(winCoins)} 🪙", color = Color.White, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(3.dp))
            Button(
                onClick = onSpin,
                enabled = !spinning,
                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White, disabledContainerColor = RedDark),
                modifier = Modifier.fillMaxWidth().height(if (compact) 84.dp else 90.dp),
                shape = RoundedCornerShape(21.dp),
                border = BorderStroke(4.dp, RedDark)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (spinning) "GIRANDO..." else "SPIN", fontSize = if (compact) 30.sp else 34.sp, fontWeight = FontWeight.Black)
                    if (!spinning) Text("Tieni premuto per spin automatici", fontSize = 7.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AnimatedReel(icon: String, spinning: Boolean, index: Int, modifier: Modifier) {
    var display by remember { mutableStateOf(icon) }
    val offset = remember { Animatable(0f) }
    val delayStart = index * 55L

    LaunchedEffect(spinning) {
        if (!spinning) {
            display = icon
            offset.snapTo(0f)
            return@LaunchedEffect
        }
        delay(delayStart)
        val symbols = slotSymbols.map { it.icon }
        val stopAfter = 1450L + index * 400L
        val started = System.currentTimeMillis()
        while (System.currentTimeMillis() - started < stopAfter) {
            display = symbols.random()
            offset.snapTo(-42f)
            offset.animateTo(0f, tween(75))
            delay(15)
        }
        display = icon
        offset.animateTo(0f, tween(180))
    }

    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Cream)
            .border(3.dp, Color(0xFF24251C), RoundedCornerShape(16.dp))
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
            Text(slotSymbols[(index + 2) % slotSymbols.size].icon, fontSize = 30.sp)
            Box(Modifier.fillMaxWidth().height(78.dp).clipToBounds(), contentAlignment = Alignment.Center) {
                AnimatedContent(
                    targetState = display,
                    transitionSpec = {
                        slideInVertically(animationSpec = tween(70)) { -it } + fadeIn(tween(40)) togetherWith
                            slideOutVertically(animationSpec = tween(70)) { it } + fadeOut(tween(40))
                    },
                    label = "reel_$index"
                ) { value ->
                    Text(value, fontSize = 47.sp, modifier = Modifier.offset(y = offset.value.dp).padding(top = 1.dp))
                }
            }
            Text(slotSymbols[(index + 5) % slotSymbols.size].icon, fontSize = 30.sp)
        }
    }
}

@Composable
private fun InfoBox(title: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(OliveDark).border(1.dp, Color(0xFF647344), RoundedCornerShape(14.dp)).padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color(0xFFC8CDBB), fontSize = 8.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun MultiplierBox(selected: Int, onChange: (Int) -> Unit, modifier: Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(14.dp)).background(OliveDark).border(1.dp, Color(0xFF647344), RoundedCornerShape(14.dp)).padding(horizontal = 4.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("−", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected - 1).coerceAtLeast(1)) }.padding(horizontal = 4.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("MOLTIPLICATORE", color = Color(0xFFC8CDBB), fontSize = 7.sp, fontWeight = FontWeight.Bold)
            Text("X$selected", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
        Text("+", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected + 1).coerceAtMost(5)) }.padding(horizontal = 4.dp))
    }
}

@Composable
private fun MiniSideCard(icon: String, title: String, value: String) {
    Card(
        Modifier.fillMaxWidth().height(104.dp).shadow(5.dp, RoundedCornerShape(15.dp)),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = OliveDark),
        border = BorderStroke(2.dp, Color(0xFF6B7947))
    ) {
        Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 28.sp)
            Text(title, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Text(value, color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SpinCounter(spins: Int, rechargeSeconds: Int, modifier: Modifier) {
    Card(
        modifier.height(82.dp).shadow(5.dp, RoundedCornerShape(17.dp)),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = OliveDark),
        border = BorderStroke(2.dp, Color(0xFF647344))
    ) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("GIRI DISPONIBILI", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("🪖", fontSize = 22.sp); Text("$spins", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black); Text("+", color = Color.White, fontSize = 20.sp) }
            Text(if (spins >= MAX_SPINS) "CAPACITÀ 100" else "+1 GIRO TRA ${rechargeSeconds / 60}:${(rechargeSeconds % 60).toString().padStart(2, '0')}", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SuperSpinCard(modifier: Modifier) {
    Card(
        modifier.height(82.dp).shadow(5.dp, RoundedCornerShape(17.dp)),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = Blue),
        border = BorderStroke(2.dp, Color(0xFF6EB9E0))
    ) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🚀", fontSize = 25.sp)
            Text("SUPER SPIN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
            Text("ATTIVO", color = Gold, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun SideEvent(icon: String, title: String, value: String, color: Color, modifier: Modifier) {
    Card(
        modifier.shadow(6.dp, RoundedCornerShape(15.dp)),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        border = BorderStroke(2.dp, Color(0xFF6F7C62))
    ) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 29.sp)
            Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp, textAlign = TextAlign.Center)
            Text(value, color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp)
        }
    }
}

@Composable
private fun BottomGameBar() {
    NavigationBar(containerColor = Color(0xFF172511), tonalElevation = 0.dp) {
        listOf("📦" to "NEGOZIO", "🃏" to "CARTE", "🎰" to "SLOT", "🏠" to "BASE", "🛡️" to "ALLEANZA").forEachIndexed { i, item ->
            NavigationBarItem(
                selected = i == 2,
                onClick = {},
                icon = { Text(item.first, fontSize = if (i == 2) 26.sp else 21.sp) },
                label = { Text(item.second, fontSize = 8.sp, fontWeight = FontWeight.Black) }
            )
        }
    }
}

private class GameSound(context: Context) {
    private val pool: SoundPool
    private val music: MediaPlayer?
    private val spinId: Int
    private val winId: Int
    private val loseId: Int
    private val tapId: Int
    private var enabled = true

    init {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        pool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(4).build()
        spinId = pool.load(context, R.raw.slot_spin, 1)
        winId = pool.load(context, R.raw.slot_win, 1)
        loseId = pool.load(context, R.raw.slot_lose, 1)
        tapId = pool.load(context, R.raw.slot_tap, 1)
        music = MediaPlayer.create(context, R.raw.frontline_music)?.apply { isLooping = true; setVolume(0.18f, 0.18f) }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        if (enabled) {
            if (music?.isPlaying == false) music.start()
        } else if (music?.isPlaying == true) {
            music.pause()
        }
    }

    fun spin() { if (enabled) pool.play(spinId, .55f, .55f, 1, 0, 1f) }
    fun win() { if (enabled) pool.play(winId, .75f, .75f, 1, 0, 1.05f) }
    fun lose() { if (enabled) pool.play(loseId, .4f, .4f, 1, 0, .9f) }
    fun tap() { if (enabled) pool.play(tapId, .25f, .25f, 1, 0, 1.2f) }
    fun release() { if (music?.isPlaying == true) music.stop(); music?.release(); pool.release() }
}
