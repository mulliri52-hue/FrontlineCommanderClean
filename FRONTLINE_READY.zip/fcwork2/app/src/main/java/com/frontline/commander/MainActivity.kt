package com.frontline.commander

import android.app.Activity
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.random.Random

private val Olive = Color(0xFF52652D)
private val OliveDark = Color(0xFF293719)
private val Metal = Color(0xFF9B9A82)
private val MetalDark = Color(0xFF454638)
private val Gold = Color(0xFFFFC62E)
private val GoldDark = Color(0xFF9B6413)
private val Red = Color(0xFFD8432E)
private val RedDark = Color(0xFF7F2018)
private val Blue = Color(0xFF1976A8)
private val Sky = Color(0xFF6DB3D8)
private val Cream = Color(0xFFFFF7DE)
private val Ink = Color(0xFF252A1E)
private val Purple = Color(0xFF6B3E98)

private const val MAX_SPINS = 100
private const val STARTING_SPINS = 17
private const val SPIN_RECHARGE_MS = 3 * 60 * 1000L
private const val REWARDED_AD_TEST_ID = "ca-app-pub-3940256099942544/5224354917"
private const val BANNER_AD_ID = "ca-app-pub-3355766770615296/8061386012"

private data class Symbol(val icon: String, val name: String)
private data class WinRule(val symbol: String, val label: String, val multiplier: Int)

private val slotSymbols = listOf(
    Symbol("🪖", "ELMETTO"),
    Symbol("🎖️", "MEDAGLIA"),
    Symbol("🚁", "ELICOTTERO"),
    Symbol("🛡️", "CARRO"),
    Symbol("📦", "CASSA"),
    Symbol("✈️", "AEREO"),
    Symbol("💣", "GRANATA"),
    Symbol("⭐", "STELLA")
)

private val winRules = listOf(
    WinRule("🪖", "ELMETTI", 2),
    WinRule("🚁", "ELICOTTERI", 10),
    WinRule("🛡️", "CARRI", 15),
    WinRule("📦", "CASSE", 4),
    WinRule("✈️", "AEREI", 20),
    WinRule("⭐", "STELLE", 50)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        setContent { FrontlineApp() }
    }
}

private class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("frontline_game", Context.MODE_PRIVATE)
    var coins: Int get() = prefs.getInt("coins", 8450000) ; set(v) = prefs.edit().putInt("coins", v.coerceAtLeast(0)).apply()
    var spins: Int get() = prefs.getInt("spins", STARTING_SPINS).coerceIn(0, MAX_SPINS) ; set(v) = prefs.edit().putInt("spins", v.coerceIn(0, MAX_SPINS)).apply()
    var power: Int get() = prefs.getInt("power", 18) ; set(v) = prefs.edit().putInt("power", v.coerceAtLeast(0)).apply()
    var maxPower: Int get() = prefs.getInt("maxPower", 50) ; set(v) = prefs.edit().putInt("maxPower", v.coerceAtLeast(1)).apply()
    var xp: Int get() = prefs.getInt("xp", 560) ; set(v) = prefs.edit().putInt("xp", v.coerceAtLeast(0)).apply()
    var hq: Int get() = prefs.getInt("hq", 2) ; set(v) = prefs.edit().putInt("hq", v.coerceAtLeast(1)).apply()
    var streak: Int get() = prefs.getInt("streak", 1) ; set(v) = prefs.edit().putInt("streak", v.coerceAtLeast(1)).apply()
    var lastSpinRecharge: Long get() = prefs.getLong("last_spin_recharge", System.currentTimeMillis()) ; set(v) = prefs.edit().putLong("last_spin_recharge", v).apply()
    var soundEnabled: Boolean get() = prefs.getBoolean("sound_enabled", true) ; set(v) = prefs.edit().putBoolean("sound_enabled", v).apply()
}

@Composable
fun FrontlineApp() {
    val context = LocalContext.current
    val store = remember { GameStore(context) }
    val sound = remember { GameSound(context) }

    var coins by remember { mutableIntStateOf(store.coins) }
    var spins by remember { mutableIntStateOf(store.spins) }
    var power by remember { mutableIntStateOf(store.power) }
    var maxPower by remember { mutableIntStateOf(store.maxPower) }
    var xp by remember { mutableIntStateOf(store.xp) }
    var hq by remember { mutableIntStateOf(store.hq) }
    var message by remember { mutableStateOf("PRONTO AL LANCIO, COMANDANTE!") }
    var reels by remember { mutableStateOf(listOf("🪖", "🎖️", "🚁")) }
    var spinning by remember { mutableStateOf(false) }
    var streak by remember { mutableIntStateOf(store.streak) }
    var rechargeSeconds by remember { mutableIntStateOf(0) }
    var selectedMultiplier by rememberSaveable { mutableIntStateOf(1) }
    var lastMultiplier by rememberSaveable { mutableIntStateOf(0) }
    var lastWinCoins by rememberSaveable { mutableIntStateOf(0) }
    var lastResult by rememberSaveable { mutableStateOf("Nessun giro ancora") }
    var soundEnabled by remember { mutableStateOf(store.soundEnabled) }
    var rewardedAd by remember { mutableStateOf<RewardedAd?>(null) }
    var adLoading by remember { mutableStateOf(false) }
    var showRewardInfo by remember { mutableStateOf(false) }
    val effectiveBet = 100_000 * selectedMultiplier

    fun persist() {
        store.coins = coins; store.spins = spins; store.power = power; store.maxPower = maxPower
        store.xp = xp; store.hq = hq; store.streak = streak; store.soundEnabled = soundEnabled
    }

    fun loadRewardedAd() {
        if (adLoading || rewardedAd != null) return
        adLoading = true
        RewardedAd.load(context, REWARDED_AD_TEST_ID, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad; adLoading = false }
            override fun onAdFailedToLoad(error: LoadAdError) { rewardedAd = null; adLoading = false }
        })
    }

    DisposableEffect(Unit) { loadRewardedAd(); onDispose { sound.release() } }
    LaunchedEffect(soundEnabled) { sound.setEnabled(soundEnabled) }
    LaunchedEffect(Unit) {
        while (true) {
            val now = System.currentTimeMillis()
            if (spins >= MAX_SPINS) rechargeSeconds = 0
            else {
                val elapsed = max(0L, now - store.lastSpinRecharge)
                val gained = (elapsed / SPIN_RECHARGE_MS).toInt()
                if (gained > 0) {
                    val actual = minOf(gained, MAX_SPINS - spins)
                    spins += actual
                    store.lastSpinRecharge += actual * SPIN_RECHARGE_MS
                    persist()
                }
                rechargeSeconds = max(0L, SPIN_RECHARGE_MS - max(0L, System.currentTimeMillis() - store.lastSpinRecharge) ) .div(1000L).toInt()
            }
            delay(1000)
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Olive)) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF182311),
                    tonalElevation = 0.dp
                ) {
                    listOf("🏕️" to "BASE", "🃏" to "CARTE", "🎰" to "SLOT", "🏠" to "BASE", "🛡️" to "ALLEANZA").forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = i == 2,
                            onClick = { if (soundEnabled) sound.tap() },
                            icon = { Text(item.first, fontSize = if (i == 2) 25.sp else 21.sp) },
                            label = { Text(item.second, fontSize = 8.sp, fontWeight = FontWeight.Black) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).background(
                Brush.verticalGradient(listOf(Color(0xFF6EB6D5), Color(0xFF9DCB89), Color(0xFF557744), Color(0xFF27381B)))
            )) {
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TopBar(xp, coins, power, soundEnabled) { soundEnabled = !soundEnabled; persist(); if (soundEnabled) sound.tap() }
                    Spacer(Modifier.height(4.dp))
                    WinningBoard()
                    Spacer(Modifier.height(5.dp))

                    BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Column(Modifier.width(62.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                MiniSideCard("🎁", "MISSIONI", "2")
                                MiniSideCard("🏆", "CLASSIFICA", "2g 14h")
                                MiniSideCard("🎁", "RICOMPENSE", "14h")
                            }
                            SlotMachine(
                                reels = reels,
                                spinning = spinning,
                                multiplier = lastMultiplier,
                                selectedMultiplier = selectedMultiplier,
                                result = lastResult,
                                winCoins = lastWinCoins,
                                message = message,
                                onMultiplierChange = { selectedMultiplier = it },
                                onSpin = {
                                    if (!spinning && spins > 0 && coins >= effectiveBet) {
                                        spinning = true
                                        val wasFull = spins == MAX_SPINS
                                        spins--
                                        coins -= effectiveBet
                                        if (wasFull) store.lastSpinRecharge = System.currentTimeMillis()
                                        power = (power - 1).coerceAtLeast(0)
                                        lastMultiplier = 0; lastWinCoins = 0; persist()
                                        message = "I RULLI STANNO GIRANDO..."
                                        if (soundEnabled) sound.spin()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                            Column(Modifier.width(62.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                SideEvent("⚡", "OPERAZIONE\nFULMINE", "2g 14h", Purple, Modifier.fillMaxWidth())
                                SideEvent("🎁", "BONUS\nGIORNALIERO", "14h", Blue, Modifier.fillMaxWidth())
                                SideEvent("▶", "VIDEO\nBONUS", "+10", RedDark, Modifier.fillMaxWidth())
                            }
                        }
                    }

                    Spacer(Modifier.height(5.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        SpinCounter(spins, rechargeSeconds, Modifier.weight(1f))
                        SuperSpinCard(Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(4.dp))
                    BannerAd()

                    LaunchedEffect(spinning) {
                        if (spinning) {
                            val bet = 100_000 * selectedMultiplier
                            val symbols = slotSymbols.map { it.icon }
                            repeat(24) { reels = List(3) { symbols.random() }; delay(70) }
                            repeat(10) { reels = List(3) { symbols.random() }; delay(125) }
                            val first = symbols.random(); repeat(5) { reels = listOf(first, symbols.random(), symbols.random()); delay(150) }
                            val second = symbols.random(); repeat(4) { reels = listOf(first, second, symbols.random()); delay(185) }
                            val third = symbols.random(); reels = listOf(first, second, third)
                            val same = first == second && second == third
                            val pair = first == second || second == third || first == third
                            when {
                                same -> {
                                    val ruleMultiplier = winRules.firstOrNull { it.symbol == first }?.multiplier ?: 2
                                    val gain = bet * ruleMultiplier + streak * 25
                                    lastMultiplier = ruleMultiplier; lastWinCoins = gain; lastResult = "$first  $second  $third"; coins += gain; xp += 25 * ruleMultiplier
                                    power = (power + 2).coerceAtMost(maxPower); streak++; message = "🏆 VITTORIA! +$gain 🪙"; if (soundEnabled) sound.win()
                                }
                                pair -> {
                                    val gain = bet * 2
                                    lastMultiplier = 2; lastWinCoins = gain; lastResult = "$first  $second  $third"; coins += gain; xp += 15; streak++; message = "🎯 DOPPIA! +$gain 🪙"; if (soundEnabled) sound.win()
                                }
                                else -> {
                                    lastMultiplier = 0; lastWinCoins = 0; lastResult = "$first  $second  $third"; xp += 5; streak = 1; message = "NESSUNA COMBINAZIONE"; if (soundEnabled) sound.lose()
                                }
                            }
                            persist(); spinning = false
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(xp: Int, coins: Int, power: Int, soundEnabled: Boolean, onSound: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(OliveDark).padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Gold), contentAlignment = Alignment.Center) { Text("🪖", fontSize = 30.sp) }
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text("FRONTLINE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text("Lv. 23   $xp/1200 XP", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        ResourcePill("🪙", compactNumber(coins), true)
        Spacer(Modifier.width(4.dp))
        ResourcePill("💎", "1.250", true)
        Spacer(Modifier.width(3.dp))
        Text(if (soundEnabled) "🔊" else "🔇", Modifier.clickable { onSound() }.padding(4.dp), fontSize = 18.sp)
    }
}

@Composable
private fun ResourcePill(icon: String, value: String, plus: Boolean) {
    Row(Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF6B783D)).padding(horizontal = 5.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 15.sp); Spacer(Modifier.width(3.dp)); Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp); if (plus) Text("+", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 3.dp))
    }
}

private fun compactNumber(value: Int): String = when { value >= 1_000_000 -> "${value / 1_000_000}.${(value / 100_000) % 10}M"; value >= 1_000 -> "${value / 1_000}.${(value / 100) % 10}K"; else -> value.toString() }

@Composable
private fun EventStrip() {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF1F2B18)).padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("⚡", fontSize = 20.sp); Spacer(Modifier.width(5.dp)); Text("OPERAZIONE FULMINE", color = Gold, fontWeight = FontWeight.Black, fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text("EVENTO ATTIVO!", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun WinningBoard() {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF39452A)), border = BorderStroke(2.dp, Color(0xFF69734E))) {
        Column(Modifier.padding(8.dp).animateContentSize()) {
            Text("COMBINAZIONI VINCENTI", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) { winRules.take(3).forEach { WinLine(it) } }
                Column(Modifier.weight(1f)) { winRules.drop(3).forEach { WinLine(it) } }
            }
            Text("ⓘ Le vincite vengono moltiplicate sulla puntata totale", color = Color(0xFFD8DDC8), fontSize = 8.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun WinLine(rule: WinRule) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${rule.symbol} ${rule.symbol} ${rule.symbol}", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text("×${rule.multiplier}", color = if (rule.multiplier >= 10) Gold else Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
    }
}

@Composable
private fun MiniAction(icon: String, title: String, badge: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = OliveDark)) {
        Column(Modifier.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 25.sp); Text(title, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center); Text(badge, color = Gold, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SlotMachine(
    reels: List<String>,
    spinning: Boolean,
    multiplier: Int,
    selectedMultiplier: Int,
    result: String,
    winCoins: Int,
    message: String,
    onMultiplierChange: (Int) -> Unit,
    onSpin: () -> Unit,
    modifier: Modifier
) {
    Card(
        modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF4A4D38)),
        border = BorderStroke(3.dp, Color(0xFF7C7A58))
    ) {
        Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF454936), Color(0xFF77785B), Color(0xFF454936)))), contentAlignment = Alignment.Center) {
                Text("⚔  FRONTLINE COMMANDER  ⚔", color = Cream, fontWeight = FontWeight.Black, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(5.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF171A12)).border(5.dp, Color(0xFF292B1D), RoundedCornerShape(20.dp)).padding(6.dp)) {
                Row(Modifier.fillMaxWidth().height(190.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    reels.forEachIndexed { i, icon -> ReelWindow(icon, spinning, i, Modifier.weight(1f)) }
                }
            }
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                InfoBox("PUNTATA", "100.000", Modifier.weight(1f))
                MultiplierBox(selectedMultiplier, onMultiplierChange, Modifier.weight(1f))
            }
            Text(if (spinning) "I RULLI STANNO GIRANDO..." else message, color = Gold, fontWeight = FontWeight.Black, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 3.dp))
            if (!spinning && multiplier > 0) Text("$result  •  +$winCoins 🪙", color = Color.White, fontSize = 8.sp)
            Button(
                onClick = onSpin,
                enabled = !spinning,
                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White, disabledContainerColor = RedDark),
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(3.dp, RedDark)
            ) { Text(if (spinning) "GIRANDO..." else "SPIN", fontSize = 28.sp, fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
private fun ReelWindow(icon: String, spinning: Boolean, index: Int, modifier: Modifier) {
    Box(modifier.fillMaxHeight().clip(RoundedCornerShape(10.dp)).background(Cream).border(2.dp, Color(0xFF24251C), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
            Text(slotSymbols.random().icon, fontSize = 26.sp)
            AnimatedContent(targetState = icon, transitionSpec = { (slideInVertically { -it } + fadeIn()) togetherWith (slideOutVertically { it } + fadeOut()) }, label = "reel_$index") { value -> Text(value, fontSize = if (spinning) 38.sp else 42.sp) }
            Text(slotSymbols.random().icon, fontSize = 26.sp)
        }
        Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0xFF6E6A52)).align(Alignment.Center))
    }
}

@Composable
private fun InfoBox(title: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(11.dp)).background(OliveDark).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color(0xFFC8CDBB), fontSize = 7.sp, fontWeight = FontWeight.Bold); Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun MultiplierBox(selected: Int, onChange: (Int) -> Unit, modifier: Modifier) {
    Row(modifier.clip(RoundedCornerShape(11.dp)).background(OliveDark).padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("−", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected - 1).coerceAtLeast(1)) }.padding(horizontal = 4.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("MOLTIPLICATORE", color = Color(0xFFC8CDBB), fontSize = 6.sp, fontWeight = FontWeight.Bold); Text("X$selected", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Black) }
        Text("+", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected + 1).coerceAtMost(5)) }.padding(horizontal = 4.dp))
    }
}

@Composable
private fun MiniSideCard(icon: String, title: String, value: String) {
    Card(Modifier.fillMaxWidth().height(74.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = OliveDark), border = BorderStroke(1.dp, Color(0xFF667347))) {
        Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 22.sp); Text(title, color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center); Text(value, color = Gold, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SpinCounter(spins: Int, rechargeSeconds: Int, modifier: Modifier) {
    Card(modifier.height(64.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = OliveDark)) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("GIRI DISPONIBILI", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("🪖", fontSize = 18.sp); Text("$spins", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black); Text("+", color = Color.White, fontSize = 17.sp) }
            Text(if (spins >= MAX_SPINS) "CAPACITÀ 100" else "+1 GIRO ${rechargeSeconds / 60}:${(rechargeSeconds % 60).toString().padStart(2, '0')}", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SuperSpinCard(modifier: Modifier) {
    Card(modifier.height(64.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Blue)) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🚀", fontSize = 18.sp); Text("SUPER SPIN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp); Text("ATTIVO", color = Gold, fontWeight = FontWeight.Black, fontSize = 8.sp)
        }
    }
}

@Composable
private fun ControlPanel(spins: Int, rechargeSeconds: Int, onBonus: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Card(Modifier.weight(1f), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = OliveDark)) {
            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("GIRI DISPONIBILI", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("🪖", fontSize = 24.sp); Text("$spins", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black); Text("+", color = Color.White, fontSize = 20.sp) }
                Text(if (spins >= MAX_SPINS) "CAPACITÀ MASSIMA" else "+1 GIRO TRA ${rechargeSeconds / 60}:${(rechargeSeconds % 60).toString().padStart(2, '0')}", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            }
        }
        Card(Modifier.weight(1f).clickable { onBonus() }, shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Blue)) {
            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("🚀", fontSize = 26.sp); Text("VIDEO BONUS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp); Text("+10 GIRI", color = Gold, fontWeight = FontWeight.Black, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun SideEvent(icon: String, title: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = color)) {
        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, fontSize = 26.sp); Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp, textAlign = TextAlign.Center); Text(value, color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp) }
    }
}

@Composable
private fun BaseProgress(power: Int, maxPower: Int, hq: Int) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xD926321C))) {
        Column(Modifier.padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("BASE AVANZATA", color = Color.White, fontWeight = FontWeight.Black); Text("LV.$hq", color = Gold, fontWeight = FontWeight.Black) }
            Text("⚡ POTERE OPERATIVO  $power/$maxPower", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp)); LinearProgressIndicator(progress = { power.toFloat() / maxPower.toFloat() }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)), color = Gold, trackColor = Color(0xFF5D674A))
        }
    }
}

@Composable
private fun BannerAd() {
    AndroidView<AdView>(factory = { ctx -> AdView(ctx).apply { adUnitId = BANNER_AD_ID; setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(ctx, 360)); loadAd(AdRequest.Builder().build()) } }, modifier = Modifier.fillMaxWidth())
}

private class GameSound(context: Context) {
    private val pool: SoundPool
    private val music: MediaPlayer
    private val spinId: Int
    private val winId: Int
    private val loseId: Int
    private val tapId: Int
    private var enabled = true
    init {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        pool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(4).build()
        spinId = pool.load(context, R.raw.slot_spin, 1); winId = pool.load(context, R.raw.slot_win, 1); loseId = pool.load(context, R.raw.slot_lose, 1); tapId = pool.load(context, R.raw.slot_tap, 1)
        music = MediaPlayer.create(context, R.raw.frontline_music).apply { isLooping = true; setVolume(0.18f, 0.18f) }
    }
    fun setEnabled(value: Boolean) { enabled = value; if (enabled) { if (!music.isPlaying) music.start() } else if (music.isPlaying) music.pause() }
    fun spin() { if (enabled) pool.play(spinId, .55f, .55f, 1, 0, 1f) }
    fun win() { if (enabled) pool.play(winId, .75f, .75f, 1, 0, 1.05f) }
    fun lose() { if (enabled) pool.play(loseId, .4f, .4f, 1, 0, .9f) }
    fun tap() { if (enabled) pool.play(tapId, .25f, .25f, 1, 0, 1.2f) }
    fun release() { if (music.isPlaying) music.stop(); music.release(); pool.release() }
}
