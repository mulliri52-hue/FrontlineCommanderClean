package com.frontline.commander

import android.app.Activity
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.random.Random

private val Olive = Color(0xFF52652D)
private val OliveDark = Color(0xFF293719)
private val Metal = Color(0xFF9B9A82)
private val MetalDark = Color(0xFF454638)
private val Gold = Color(0xFFFFC62E)
private val GoldDark = Color(0xFF9B6413)
private val Red = Color(0xFFD8432E)
private val RedDark = Color(0xFF7F2018)
private val Blue = Color(0xFF1976A8)
private val Sky = Color(0xFF6DB3D8)
private val Cream = Color(0xFFFFF7DE)
private val Ink = Color(0xFF252A1E)
private val Purple = Color(0xFF6B3E98)

private const val MAX_SPINS = 100
private const val STARTING_SPINS = 17
private const val SPIN_RECHARGE_MS = 3 * 60 * 1000L
private const val REWARDED_AD_TEST_ID = "ca-app-pub-3940256099942544/5224354917"
private const val BANNER_AD_ID = "ca-app-pub-3355766770615296/8061386012"

private data class Symbol(val icon: String, val name: String)
private data class WinRule(val symbol: String, val label: String, val multiplier: Int)

private val slotSymbols = listOf(
    Symbol("🪖", "ELMETTO"),
    Symbol("🎖️", "MEDAGLIA"),
    Symbol("🚁", "ELICOTTERO"),
    Symbol("🛡️", "CARRO"),
    Symbol("📦", "CASSA"),
    Symbol("✈️", "AEREO"),
    Symbol("💣", "GRANATA"),
    Symbol("⭐", "STELLA")
)

private val winRules = listOf(
    WinRule("🪖", "ELMETTI", 2),
    WinRule("🚁", "ELICOTTERI", 10),
    WinRule("🛡️", "CARRI", 15),
    WinRule("📦", "CASSE", 4),
    WinRule("✈️", "AEREI", 20),
    WinRule("⭐", "STELLE", 50)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        setContent { FrontlineApp() }
    }
}

private class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("frontline_game", Context.MODE_PRIVATE)
    var coins: Int get() = prefs.getInt("coins", 8450000) ; set(v) = prefs.edit().putInt("coins", v.coerceAtLeast(0)).apply()
    var spins: Int get() = prefs.getInt("spins", STARTING_SPINS).coerceIn(0, MAX_SPINS) ; set(v) = prefs.edit().putInt("spins", v.coerceIn(0, MAX_SPINS)).apply()
    var power: Int get() = prefs.getInt("power", 18) ; set(v) = prefs.edit().putInt("power", v.coerceAtLeast(0)).apply()
    var maxPower: Int get() = prefs.getInt("maxPower", 50) ; set(v) = prefs.edit().putInt("maxPower", v.coerceAtLeast(1)).apply()
    var xp: Int get() = prefs.getInt("xp", 560) ; set(v) = prefs.edit().putInt("xp", v.coerceAtLeast(0)).apply()
    var hq: Int get() = prefs.getInt("hq", 2) ; set(v) = prefs.edit().putInt("hq", v.coerceAtLeast(1)).apply()
    var streak: Int get() = prefs.getInt("streak", 1) ; set(v) = prefs.edit().putInt("streak", v.coerceAtLeast(1)).apply()
    var lastSpinRecharge: Long get() = prefs.getLong("last_spin_recharge", System.currentTimeMillis()) ; set(v) = prefs.edit().putLong("last_spin_recharge", v).apply()
    var soundEnabled: Boolean get() = prefs.getBoolean("sound_enabled", true) ; set(v) = prefs.edit().putBoolean("sound_enabled", v).apply()
}

@Composable
fun FrontlineApp() {
    val context = LocalContext.current
    val store = remember { GameStore(context) }
    val sound = remember { GameSound(context) }
    var coins by remember { mutableIntStateOf(store.coins) }
    var spins by remember { mutableIntStateOf(store.spins) }
    var power by remember { mutableIntStateOf(store.power) }
    var maxPower by remember { mutableIntStateOf(store.maxPower) }
    var xp by remember { mutableIntStateOf(store.xp) }
    var message by remember { mutableStateOf("PRONTO AL LANCIO, COMANDANTE!") }
    var reels by remember { mutableStateOf(listOf("🪖", "🎖️", "🚁")) }
    var spinning by remember { mutableStateOf(false) }
    var streak by remember { mutableIntStateOf(store.streak) }
    var rechargeSeconds by remember { mutableIntStateOf(0) }
    var selectedMultiplier by rememberSaveable { mutableIntStateOf(1) }
    var lastMultiplier by rememberSaveable { mutableIntStateOf(0) }
    var lastWinCoins by rememberSaveable { mutableIntStateOf(0) }
    var lastResult by rememberSaveable { mutableStateOf("Nessun giro ancora") }
    var soundEnabled by remember { mutableStateOf(store.soundEnabled) }
    val effectiveBet = 100_000 * selectedMultiplier

    fun persist() {
        store.coins = coins; store.spins = spins; store.power = power; store.maxPower = maxPower
        store.xp = xp; store.streak = streak; store.soundEnabled = soundEnabled
    }

    DisposableEffect(Unit) { onDispose { sound.release() } }
    LaunchedEffect(soundEnabled) { sound.setEnabled(soundEnabled) }
    LaunchedEffect(Unit) {
        while (true) {
            val now = System.currentTimeMillis()
            if (spins >= MAX_SPINS) rechargeSeconds = 0
            else {
                val elapsed = max(0L, now - store.lastSpinRecharge)
                val gained = (elapsed / SPIN_RECHARGE_MS).toInt()
                if (gained > 0) {
                    val actual = minOf(gained, MAX_SPINS - spins)
                    spins += actual
                    store.lastSpinRecharge += actual * SPIN_RECHARGE_MS
                    persist()
                }
                rechargeSeconds = max(0L, SPIN_RECHARGE_MS - max(0L, System.currentTimeMillis() - store.lastSpinRecharge)).div(1000L).toInt()
            }
            delay(1000)
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Olive)) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = { BottomGameBar() }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).background(
                Brush.verticalGradient(listOf(Color(0xFF7FB8D0), Color(0xFF88B56C), Color(0xFF435B2C), Color(0xFF1C2B16)))
            )) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp)) {
                    TopBar(xp, coins, power, soundEnabled) { soundEnabled = !soundEnabled; persist(); if (soundEnabled) sound.tap() }
                    Spacer(Modifier.height(6.dp))
                    WinningBoard()
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Column(Modifier.width(88.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            MiniSideCard("🎁", "MISSIONI", "2")
                            MiniSideCard("🏆", "CLASSIFICA", "2g 14h")
                            MiniSideCard("🎁", "RICOMPENSE", "14h")
                        }
                        SlotMachine(
                            reels = reels,
                            spinning = spinning,
                            multiplier = lastMultiplier,
                            selectedMultiplier = selectedMultiplier,
                            result = lastResult,
                            winCoins = lastWinCoins,
                            message = message,
                            onMultiplierChange = { selectedMultiplier = it },
                            onSpin = {
                                if (!spinning && spins > 0 && coins >= effectiveBet) {
                                    spinning = true
                                    if (spins == MAX_SPINS) store.lastSpinRecharge = System.currentTimeMillis()
                                    spins--; coins -= effectiveBet; power = (power - 1).coerceAtLeast(0)
                                    lastMultiplier = 0; lastWinCoins = 0; persist(); message = "I RULLI STANNO GIRANDO..."; if (soundEnabled) sound.spin()
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        Column(Modifier.width(92.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            SideEvent("⚡", "OPERAZIONE
FULMINE", "2g 14h", Purple, Modifier.fillMaxWidth().height(142.dp))
                            SideEvent("🎁", "BONUS
GIORNALIERO", "14h", Blue, Modifier.fillMaxWidth().height(118.dp))
                            SideEvent("▶", "VIDEO
BONUS", "+10", Color(0xFF285A82), Modifier.fillMaxWidth().height(95.dp))
                        }
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SpinCounter(spins, rechargeSeconds, Modifier.weight(1f))
                        SuperSpinCard(Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    if (message.contains("VITTORIA") || message.contains("DOPPIA")) {
                        Text(message, color = Gold, fontWeight = FontWeight.Black, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(4.dp))
                    }
                }
            }
        }
    }

    LaunchedEffect(spinning) {
        if (spinning) {
            val bet = 100_000 * selectedMultiplier
            val symbols = slotSymbols.map { it.icon }
            repeat(24) { reels = List(3) { symbols.random() }; delay(70) }
            repeat(10) { reels = List(3) { symbols.random() }; delay(125) }
            val first = symbols.random(); repeat(5) { reels = listOf(first, symbols.random(), symbols.random()); delay(150) }
            val second = symbols.random(); repeat(4) { reels = listOf(first, second, symbols.random()); delay(185) }
            val third = symbols.random(); reels = listOf(first, second, third)
            val same = first == second && second == third
            val pair = first == second || second == third || first == third
            when {
                same -> { val ruleMultiplier = winRules.firstOrNull { it.symbol == first }?.multiplier ?: 2; val gain = bet * ruleMultiplier + streak * 25; lastMultiplier = ruleMultiplier; lastWinCoins = gain; lastResult = "$first  $second  $third"; coins += gain; xp += 25 * ruleMultiplier; power = (power + 2).coerceAtMost(maxPower); streak++; message = "🏆 VITTORIA! +$gain 🪙"; if (soundEnabled) sound.win() }
                pair -> { val gain = bet * 2; lastMultiplier = 2; lastWinCoins = gain; lastResult = "$first  $second  $third"; coins += gain; xp += 15; streak++; message = "🎯 DOPPIA! +$gain 🪙"; if (soundEnabled) sound.win() }
                else -> { lastMultiplier = 0; lastWinCoins = 0; lastResult = "$first  $second  $third"; xp += 5; streak = 1; message = "NESSUNA COMBINAZIONE"; if (soundEnabled) sound.lose() }
            }
            persist(); spinning = false
        }
    }
}

@Composable
private fun TopBar(xp: Int, coins: Int, power: Int, soundEnabled: Boolean, onSound: () -> Unit) {
    Row(Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(OliveDark).border(2.dp, Color(0xFF6F7C45), RoundedCornerShape(18.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(15.dp)).background(Gold).border(2.dp, GoldDark, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text("🪖", fontSize = 32.sp) }
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Text("FRONTLINE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("LV. 23", color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp); Spacer(Modifier.width(8.dp)); Text("$xp/1200 XP", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
        }
        ResourcePill("🪙", compactNumber(coins), true)
        Spacer(Modifier.width(5.dp)); ResourcePill("💎", "1.250", true)
        Text(if (soundEnabled) "🔊" else "🔇", Modifier.clickable { onSound() }.padding(5.dp), fontSize = 18.sp)
    }
}

@Composable private fun ResourcePill(icon: String, value: String, plus: Boolean) {
    Row(Modifier.clip(RoundedCornerShape(11.dp)).background(Color(0xFF66763A)).border(1.dp, Color(0xFF87955A), RoundedCornerShape(11.dp)).padding(horizontal = 6.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 15.sp); Spacer(Modifier.width(3.dp)); Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp); if (plus) Text("+", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 3.dp))
    }
}

private fun compactNumber(value: Int): String = when { value >= 1_000_000 -> "${value / 1_000_000}.${(value / 100_000) % 10}M"; value >= 1_000 -> "${value / 1_000}.${(value / 100) % 10}K"; else -> value.toString() }

@Composable private fun WinningBoard() {
    Card(Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(20.dp)), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF344326)), border = BorderStroke(3.dp, Color(0xFF717A4D))) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 8.dp)) {
            Text("COMBINAZIONI VINCENTI", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) { Column(Modifier.weight(1f)) { WinLine(winRules[0]); WinLine(winRules[1]); WinLine(winRules[2]) }; Column(Modifier.weight(1f)) { WinLine(winRules[3]); WinLine(winRules[4]); WinLine(winRules[5]) } }
            Text("ⓘ  Le vincite vengono moltiplicate sulla puntata totale", color = Color(0xFFD8DDC8), fontSize = 8.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}

@Composable private fun WinLine(rule: WinRule) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${rule.symbol} ${rule.symbol} ${rule.symbol}", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f)); Text("×${rule.multiplier}", color = Gold, fontWeight = FontWeight.Black, fontSize = 15.sp)
    }
}

@Composable private fun SlotMachine(reels: List<String>, spinning: Boolean, multiplier: Int, selectedMultiplier: Int, result: String, winCoins: Int, message: String, onMultiplierChange: (Int) -> Unit, onSpin: () -> Unit, modifier: Modifier) {
    // Scenario dietro la cornice della slot: cielo, colline e vegetazione. La macchina resta in primo piano.
    Box(
        modifier
            .shadow(12.dp, RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xFF789E58))
            .border(5.dp, Color(0xFF3C412B), RoundedCornerShape(28.dp))
    ) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            drawRect(Color(0xFF78B6D1), size = size)
            drawCircle(Color(0xFFFFD66B), radius = w * .10f, center = androidx.compose.ui.geometry.Offset(w * .82f, h * .10f))
            drawOval(Color(0xFF8EB56A), androidx.compose.ui.geometry.Rect(-w*.15f, h*.35f, w*.70f, h*.85f))
            drawOval(Color(0xFF638D49), androidx.compose.ui.geometry.Rect(w*.35f, h*.30f, w*1.15f, h*.85f))
            drawRect(Color(0xFF456B38), topLeft = androidx.compose.ui.geometry.Offset(0f, h*.68f), size = androidx.compose.ui.geometry.Size(w, h*.32f))
            // Sagome semplici di alberi ai lati, dietro la macchina.
            for (x in listOf(w*.06f, w*.18f, w*.88f, w*.97f)) {
                drawRect(Color(0xFF5B402B), topLeft = androidx.compose.ui.geometry.Offset(x-w*.012f, h*.48f), size = androidx.compose.ui.geometry.Size(w*.024f, h*.24f))
                drawCircle(Color(0xFF31582D), radius = w*.055f, center = androidx.compose.ui.geometry.Offset(x, h*.46f))
            }
        }
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xCC4D503B)),
            border = BorderStroke(4.dp, Color(0xFF777656))
        ) {
            Column(Modifier.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFF6E704F), Color(0xFF36392C)))).border(3.dp, Color(0xFF92916A), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                Text("⚔  FRONTLINE  ⚔
      COMMANDER  ⚔", color = Cream, fontWeight = FontWeight.Black, fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 16.sp)
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(285.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF151811)).border(7.dp, Color(0xFF2E3024), RoundedCornerShape(22.dp)).padding(7.dp)) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(5.dp)) { reels.forEachIndexed { i, icon -> ReelWindow(icon, spinning, i, Modifier.weight(1f)) } }
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                InfoBox("PUNTATA TOTALE", "100.000", Modifier.weight(1f)); MultiplierBox(selectedMultiplier, onMultiplierChange, Modifier.weight(1.25f))
            }
            Text(if (spinning) "I RULLI STANNO GIRANDO..." else message, color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 4.dp))
            if (!spinning && multiplier > 0) Text("$result  •  +$winCoins 🪙", color = Color.White, fontSize = 8.sp)
            Button(onClick = onSpin, enabled = !spinning, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White, disabledContainerColor = RedDark), modifier = Modifier.fillMaxWidth().height(78.dp), shape = RoundedCornerShape(20.dp), border = BorderStroke(4.dp, RedDark)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(if (spinning) "GIRANDO..." else "SPIN", fontSize = 31.sp, fontWeight = FontWeight.Black); if (!spinning) Text("Tieni premuto per spin automatici", fontSize = 7.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable private fun ReelWindow(icon: String, spinning: Boolean, index: Int, modifier: Modifier) {
    Box(modifier.fillMaxHeight().clip(RoundedCornerShape(15.dp)).background(Cream).border(3.dp, Color(0xFF24251C), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
            Text(slotSymbols[(index + 2) % slotSymbols.size].icon, fontSize = 31.sp)
            AnimatedContent(targetState = icon, transitionSpec = { (slideInVertically { -it } + fadeIn()) togetherWith (slideOutVertically { it } + fadeOut()) }, label = "reel_$index") { value -> Text(value, fontSize = if (spinning) 43.sp else 49.sp) }
            Text(slotSymbols[(index + 5) % slotSymbols.size].icon, fontSize = 31.sp)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0xFF6E6A52)).align(Alignment.Center))
    }
}

@Composable private fun InfoBox(title: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(13.dp)).background(OliveDark).border(1.dp, Color(0xFF647344), RoundedCornerShape(13.dp)).padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color(0xFFC8CDBB), fontSize = 8.sp, fontWeight = FontWeight.Bold); Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}

@Composable private fun MultiplierBox(selected: Int, onChange: (Int) -> Unit, modifier: Modifier) {
    Row(modifier.clip(RoundedCornerShape(13.dp)).background(OliveDark).border(1.dp, Color(0xFF647344), RoundedCornerShape(13.dp)).padding(horizontal = 5.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("−", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected - 1).coerceAtLeast(1)) }.padding(horizontal = 5.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("MOLTIPLICATORE", color = Color(0xFFC8CDBB), fontSize = 7.sp, fontWeight = FontWeight.Bold); Text("X$selected", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Black) }
        Text("+", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { onChange((selected + 1).coerceAtMost(5)) }.padding(horizontal = 5.dp))
    }
}

@Composable private fun MiniSideCard(icon: String, title: String, value: String) {
    Card(Modifier.fillMaxWidth().height(105.dp).shadow(5.dp, RoundedCornerShape(15.dp)), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = OliveDark), border = BorderStroke(2.dp, Color(0xFF6B7947))) {
        Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text(icon, fontSize = 29.sp); Text(title, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center); Text(value, color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun SpinCounter(spins: Int, rechargeSeconds: Int, modifier: Modifier) {
    Card(modifier.height(82.dp).shadow(5.dp, RoundedCornerShape(17.dp)), shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = OliveDark), border = BorderStroke(2.dp, Color(0xFF647344))) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text("GIRI DISPONIBILI", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black); Row(verticalAlignment = Alignment.CenterVertically) { Text("🪖", fontSize = 22.sp); Text("$spins", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black); Text("+", color = Color.White, fontSize = 20.sp) }; Text(if (spins >= MAX_SPINS) "CAPACITÀ 100" else "+1 GIRO TRA ${rechargeSeconds / 60}:${(rechargeSeconds % 60).toString().padStart(2, '0')}", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun SuperSpinCard(modifier: Modifier) {
    Card(modifier.height(82.dp).shadow(5.dp, RoundedCornerShape(17.dp)), shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Blue), border = BorderStroke(2.dp, Color(0xFF6EB9E0))) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text("🚀", fontSize = 25.sp); Text("SUPER SPIN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp); Text("ATTIVO", color = Gold, fontWeight = FontWeight.Black, fontSize = 9.sp) }
    }
}

@Composable private fun SideEvent(icon: String, title: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier.shadow(6.dp, RoundedCornerShape(15.dp)), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = color), border = BorderStroke(2.dp, Color(0xFF6F7C62))) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text(icon, fontSize = 29.sp); Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp, textAlign = TextAlign.Center); Text(value, color = Gold, fontWeight = FontWeight.Black, fontSize = 10.sp) }
    }
}

@Composable private fun BottomGameBar() {
    NavigationBar(containerColor = Color(0xFF182311), tonalElevation = 0.dp) {
        listOf("📦" to "NEGOZIO", "🃏" to "CARTE", "🎰" to "SLOT", "🏠" to "BASE", "🛡️" to "ALLEANZA").forEachIndexed { i, item ->
            NavigationBarItem(selected = i == 2, onClick = {}, icon = { Text(item.first, fontSize = if (i == 2) 26.sp else 21.sp) }, label = { Text(item.second, fontSize = 8.sp, fontWeight = FontWeight.Black) })
        }
    }
}

private class GameSound(context: Context) {
    private val pool: SoundPool
    private val music: MediaPlayer
    private val spinId: Int
    private val winId: Int
    private val loseId: Int
    private val tapId: Int
    private var enabled = true
    init {
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        pool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(4).build()
        spinId = pool.load(context, R.raw.slot_spin, 1); winId = pool.load(context, R.raw.slot_win, 1); loseId = pool.load(context, R.raw.slot_lose, 1); tapId = pool.load(context, R.raw.slot_tap, 1)
        music = MediaPlayer.create(context, R.raw.frontline_music).apply { isLooping = true; setVolume(0.18f, 0.18f) }
    }
    fun setEnabled(value: Boolean) { enabled = value; if (enabled) { if (!music.isPlaying) music.start() } else if (music.isPlaying) music.pause() }
    fun spin() { if (enabled) pool.play(spinId, .55f, .55f, 1, 0, 1f) }
    fun win() { if (enabled) pool.play(winId, .75f, .75f, 1, 0, 1.05f) }
    fun lose() { if (enabled) pool.play(loseId, .4f, .4f, 1, 0, .9f) }
    fun tap() { if (enabled) pool.play(tapId, .25f, .25f, 1, 0, 1.2f) }
    fun release() { if (music.isPlaying) music.stop(); music.release(); pool.release() }
}
