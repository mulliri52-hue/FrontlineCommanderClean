# Frontline Commander 0.9.0

Fix grafico e funzionale:
- tutti e tre i rulli hanno una propria animazione verticale indipendente;
- ogni rullo si ferma in tempi diversi e atterra sul simbolo finale;
- i pulsanti inferiori NEGOZIO, CARTE, SLOT, BASE e ALLEANZA cambiano schermata;
- layout centrale con cornice slot, sfondo paesaggistico dietro i rulli e pannelli laterali;
- moltiplicatore x1-x5 funzionante;
- icona Frontline Commander personalizzata.

Build: Java/Kotlin JVM 17, Gradle 8.13.
