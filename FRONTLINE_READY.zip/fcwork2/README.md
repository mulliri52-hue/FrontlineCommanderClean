# Frontline Commander

Android game prototype built with Kotlin + Jetpack Compose.

## Build

The GitHub Actions workflow installs Java 17 and uses the Gradle 8.13 wrapper, then builds `assembleDebug`. Java and Kotlin are both targeted to JVM 17.

## AdMob

The project contains a banner integration dependency. The manifest currently uses Google's test App ID. Replace it with the AdMob **App ID** (`ca-app-pub-...~...`) before release, and use the production banner ad unit only for release builds. During development, use Google's test banner ID.


## Frontline Commander V2
- Rebuilt the main screen around a large military slot-machine layout.
- Added a winning-combinations board above the reels.
- Added animated reel transitions and large SPIN control.
- Added multiplier/payout panels, spin counter with 3-minute recharge, bonus-video area, event cards and bottom navigation.
- Preserved local persistence and existing audio/rewarded-ad logic.
- Version 0.5.0 / versionCode 5.


## V0.6.0 — UI Frontline
- Layout redesigned to closely follow the supplied reference screenshot: top resources, winning-combination board, central military slot machine, side event cards, spin counter, Super Spin and bottom navigation.
- Multiplier is player-selectable from x1 to x5. The selected multiplier changes the effective stake (100,000 × multiplier) and therefore the payout.
- Spin capacity remains 100 and recharge remains one spin every 3 minutes.
- Existing sound effects and background music are retained.
- Visuals are original military-themed UI elements inspired by the reference layout, without copying proprietary logos/assets.
